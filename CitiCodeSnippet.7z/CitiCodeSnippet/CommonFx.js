Ext.define("SMDU.view.common.CommonFx", { 
 ////extend:"Object",
 alias:"widget.bi_common_functions",
 
 border:false,
 layout:"fit",
 autoScroll:true,
 
 //singleton: true,
 
 requires:[
    //'SMDU.view.create.emailtemplate.TemplateWizard'
 ],
 
 exportChart: function(chart){
		var me = this,
		 	url = Constants.URL_DOWNLOAD_CHART,
		 	imageData = chart.getImage();
//		chart.download({
//			filename: 'chart'
//		});
		imageData.fileName = 'chart';
		me.downloadExcelFile(url, imageData, 'includeFile');
 },
	
 timeStampLog: {'startTime': null, 'endTime': null, 'interfaceId': null},

 initComponent: function() {
	var me = this;
	//this.callParent(arguments);
 },
 
 setHomeContainerLoader: function(view_homecontainer){ 
	 SMDU.gbl.userDetail.HOME_CONT_REF = view_homecontainer || Ext.ComponentQuery.query('view_homecontainer')[0];	 
 },
  
 getHomeContainerLoader: function(){
	 if(SMDU.gbl.userDetail.HOME_CONT_REF !== undefined){
		 return SMDU.gbl.userDetail.HOME_CONT_REF;
	 }else{
		 return Ext.ComponentQuery.query('view_homecontainer')[0];
	 }  	
 },
 
 checkIfReqFromEmail:function(grid){ 
	//Note:- will be executed only when cmg from email
	 
     var parentPath = window.parent.location.href;            		          		
	 if(Ext.isEmpty(grid.swiftConfig.gridType) == true && parentPath.indexOf('inboxObject') > -1 ){
     	//CHECKING URL PARAMS Those came from Email to load inbox or details view
		if(grid !== undefined){ 
			//var inboxRef = Ext.ComponentQuery.query('view_inbox_inboxtabs')[0];
			//inboxRef.reloadGridOnURLParams(grid);
			grid.up('view_inbox_inboxtabs').reloadGridOnURLParams(grid);
		}                            
     }
	 else if(parentPath.indexOf('busMngrInbObject') > -1){
		 grid.up('view_inbox_inboxtabs').reloadGridOnURLParams(grid,'smdubusreqmanager');
		 grid.isBusReqManager = true;
	 }else{
     	var view_homecontainer = Ext.create('widget.bi_common_functions').getHomeContainerLoader();//Fix - 23Mar
		view_homecontainer.setLoading(false);
     }
 },
 
 showSlownessLogs: function(msg, flag, interfaceId, toggleShow){
	 var me = this;
	 var totalTime = undefined;
	 var locMsg = msg || "LOG";
	 if(Constants.showSlownessLogs == true){		 		 
		 if(flag == 'Start' || flag == 'End'){
			 var dt = Ext.util.Format.date(new Date(), 'H:i:s u');
			 
			 if(interfaceId !== undefined){me.timeStampLog.interfaceId = interfaceId;}else{me.timeStampLog.interfaceId = null}
			 if(flag == 'Start'){
				 me.timeStampLog.startTime = dt;
			 }
			 if(flag == 'End'){
				 me.timeStampLog.endTime = dt;
				 
				 var a = new Date(me.timeStampLog.startTime);
				 var b = new Date(me.timeStampLog.endTime);
				 
				 var totalTime = (b.getSeconds() - a.getSeconds());//Math.abs(b.getTime() - a.getTime()) / 1000;				 
			 }
			 
			 if(toggleShow !== 'YES'){
				 console.log(locMsg+ " - "+dt);
			 }		 
			 
			 if(totalTime !== undefined){
				 console.log("Total Time - "+ (totalTime == NaN) ? me.timeStampLog : '');
			 }			 
		 }		 
	 }
 },
 
 callCommonFxGlobally: function(){
	 return SMDU.view.common.CommonFx;
 },
 
 sendMethod: function(){
	if(Constants.RUN_APP_FOR_SLOWNESS_TEST === true){
		return 'GET';
	}else{
		return 'POST';
	}
 },
 
 resetMethod: function(){
	if(Constants.RUN_APP_FOR_SLOWNESS_TEST === true){
		return {create:'GET',read:'GET',destroy:'GET',update:'GET'}
	}else{
		return {create:'POST',read:'POST',destroy:'POST',update:'POST'}
	}
 },
	
 //Ext.String.lTrim
 lTrim: function(str, chars){ 
	 var chars = chars || "\\s*";
	 //if(typeof(value.replace) === 'function'){}
	 var regX = new RegExp("^[" + chars + "]+", "g");
	 return str.replace(regX, "");
 },
 
 rTrim: function(str, chars){
	 var chars = chars || "\\s*";	 
	 var regX = new RegExp("[" + chars + "]+$", "g");
	 return str.replace(regX, "");
 },
 
 //"17/9/2014".toDate("dd/MM/yyyy", "/")
 toDate : function(format, delimiter) {
    var date = this;
    var formatedDate = null;
    var formatLowerCase = format.toLowerCase();
    var formatItems = formatLowerCase.split(delimiter);
    var dateItems = date.split(delimiter);
    var monthIndex = formatItems.indexOf("mm");
    var monthNameIndex = formatItems.indexOf("mmm");
    var dayIndex = formatItems.indexOf("dd");
    var yearIndex = formatItems.indexOf("yyyy");
    var d = dateItems[dayIndex];
    if (d < 10) {
    	d = "0"+ d;
    }
    if (monthIndex > -1) {
        var month = parseInt(dateItems[monthIndex]);
        month -= 1;
        if (month < 10) {
            month = "0" + month;
        }
        formatedDate = new Date(dateItems[yearIndex], month, d);
    } else if (monthNameIndex > -1) {
        var monthName = dateItems[monthNameIndex];
        month = this.getMonthIndex(monthName);
        if (month < 10) {
            month = "0" + month;
        }
        formatedDate = new Date(dateItems[yearIndex], month, d);
    }
    return formatedDate;
 },

 getMonthIndex: function(name) {
    name = name.toLowerCase();
    return Ext.Date.getMonthNumber;
    /*if (name == "jan" || name == "january") {
        return 0;
    } else if (name == "feb" || name == "february") {
        return 1;
    } else if (name == "mar" || name == "march") {
        return 2;
    } else if (name == "apr" || name == "april") {
        return 3;
    } else if (name == "may" || name == "may") {
        return 4;
    } else if (name == "jun" || name == "june") {
        return 5;
    } else if (name == "jul" || name == "july") {
        return 6;
    } else if (name == "aug" || name == "august") {
        return 7;
    } else if (name == "sep" || name == "september") {
        return 8;
    } else if (name == "oct" || name == "october") {
        return 9;
    } else if (name == "nov" || name == "november") {
        return 10;
    } else if (name == "dec" || name == "december") {
        return 11;
    }*/
 },
	
 bothTrim: function(str, chars){
	return str.rTrim(chars).lTrim(chars); 
 },
 
 generateRandomUniqueNumber: function(){//13 Digit
	//Note - Send Unique Email Task ID, used to distinguish scope till email is sent
	var uniqueRandNo = Ext.util.Format.date(new Date(), 'ymdisu');
	return uniqueRandNo;
 },
 
 getPrefLanguage: function(loadedFromApp){ 
	var query = Ext.Object.fromQueryString(location.search);
	var defaultLang = "en";
    var lang = query.lang ? query.lang.toLowerCase() : SMDU.gbl.userDetail.PREF_LANG;
    if(Ext.isEmpty(lang)){
    	lang = this.getPrferedLanguageFromBackend(loadedFromApp);
    	if(Ext.isEmpty(lang)){
    		lang = defaultLang;
    	}
    }
    if (lang === 'pt' || lang === "pt_br"){
        lang = 'pt_BR';
    }
    else if (lang === 'zhcn' || lang === "zh_cn"){
        lang = 'zh_CN';
    }
    else if (lang === 'zhtw' || lang === "zh_tw"){
        lang = 'zh_TW';
    }    
		
    return lang;
 },
 
 currentLanguage: function(){
	var lang = Ext.create('widget.bi_common_functions').getPrefLanguage();
	
	if(lang !== 'en'){
		Ext.Msg.alert(lang_eng.alert_Text, lang_eng.alertOnlyEnglishLanguageOptions);
		return false;
	}
 },
	
 setLocaleUrl: function(localeCode, requestNumber, type){
	var _isType = type || false;
	var query = Ext.Object.fromQueryString(location.search)
    var loc = location.href;
    if(query.lang){
    	var from = "lang="+query.lang;
    	var to = "lang="+localeCode;
    	loc = loc.replace(from, to);
    }else{
    	if(loc.indexOf("?") === -1){
    		loc = loc + "?lang="+localeCode
    	}else{
    		loc = loc + "&lang="+localeCode
    	}
    }
    if(!Ext.isEmpty(requestNumber)){
    	if(query.reqId){
        	var from = "reqId="+query.reqId;
        	var to = "reqId="+requestNumber;
        	loc = loc.replace(from, to);
    	}else{
    		loc = loc+'&reqId='+requestNumber;
    	}
    }
    if(_isType === true){
    	return loc;
    }else{
        location.href = loc;    	
    }
 },
 
 removeParam: function (key, sourceURL) {
     //var originalURL = "http://yourewebsite.com?id=10&color_id=1";
     //var alteredURL = removeParam("color_id", originalURL);
     var rtn = sourceURL.split("?")[0],
         param,
         params_arr = [],
         queryString = (sourceURL.indexOf("?") !== -1) ? sourceURL.split("?")[1] : "";
     if (queryString !== "") {
         params_arr = queryString.split("&");
         for (var i = params_arr.length - 1; i >= 0; i -= 1) {
             param = params_arr[i].split("=")[0];
             if (param === key) {
                 params_arr.splice(i, 1);
             }
         }
         rtn = rtn + "?" + params_arr.join("&");
     }
     return rtn;
 },
 
 loadLocale: function(callBackFn, scope){
	 var lang = this.getPrefLanguage();
	 SMDU.gbl.userDetail.PREF_LANG = lang; 
	 var loadCustomLocale = function(){
	    var localeFile = Ext.util.Format.format("resources/app-locale/lang_{0}.js", lang);
        Ext.Loader.loadScript({
    		url: localeFile, 
    		onLoad: callBackFn,
    		onError: callBackFn, 
    		scope:scope
        })
     }
     var localeFile = Ext.util.Format.format("resources/ext-locale/ext-locale-{0}.js", lang);
     Ext.Loader.loadScript({
 		url: localeFile, 
 		onLoad: loadCustomLocale,
 		onError: loadCustomLocale, 
 		scope:scope
     })

 },
 
 getToLocale: function(language,requestNumber){
	 var me = this;	 
	 Ext.iterate(Constants.LANG_LIST_TO_SUPPORT, function(key, value){		 
		 if(key.toUpperCase() === language.toUpperCase()){
			 //if(value !== 'en'){
				 SMDU.gbl.userDetail.PREF_LANG = value;
				 me.setLocaleUrl(value,requestNumber);
			 //}
		 }
	 })
 },
 
 logLocalDateTime: function(){
     var serverDate = '12/12/2018 10:59:00'; // EST
     console.log(this.convertServerDateToLocal(serverDate));
 },
 
 convertESTDateToLocal: function(dateInput) { 
	if(dateInput == null || dateInput == undefined || dateInput == ""){ return ""; }
	// EST - UTC offset: 5 hours
	var offset = 5.0,	
	/*
	 - calculate the difference between the server date and UTC
	 - the value returned by the getTime method is the number of milliseconds since 1 January 1970 00:00:00 UTC.
	 - the time-zone offset is the difference, in minutes, between UTC and local time
	 - 60000 milliseconds = 60 seconds = 1 minute
	*/
	 serverDate = new Date(dateInput),
	 utc = serverDate.getTime() - (serverDate.getTimezoneOffset() * 60000);
	
	 /*
	 - apply the offset between UTC and EST (5 hours)
	 - 3600000 milliseconds = 3600 seconds = 60 minutes = 1 hour
	 */
	 var clientDate = new Date(utc + (3600000 * offset));
	 //console.log("datePassed (in EST) = "+ dateInput);
	 
	 var locDate = clientDate.toLocaleString();	 
	 var clientLocDate = locDate.replace(',', '');
	 console.log("datePassed (in EST) = "+ dateInput +" & converted date (in GMT) = "+ clientLocDate+" /r/n");
	 return clientLocDate;
 },
 
 getCurrentDate: function(datePassed){ 
	var format = 'm/d/Y H:i:s A';
	console.log("datePassed (in EST) = "+ datePassed);
	var date = Ext.Date.parse(datePassed, format);
	var newDateFramed = new Date(date.valueOf() + date.getTimezoneOffset() * 60000);
	var dateConverted = Ext.Date.format(newDateFramed, format);
	console.log("datePassed (in GMT) = "+ dateConverted);
	return dateConverted;
 },

 arrayFromObject: function(obj){
	 var theArray = [];
	 var i = 0;
	 for(var key in obj){
		 theArray[i] = 0;
		 i++;
	 }
	 return theArray;
 },
 
 getCurrentDate_old: function(datePassed){ 
	 var date = Ext.Date.parse(datePassed, 'm/d/Y H:i:s A');
	 //var date = new Date();
	 var newDate = new Date(8 * 60 * 60000 + date.valueOf() + (date.getTimezoneOffset() * 60000));
	 var ampm = newDate.getHours() < 12 ? 'AM' : 'PM';
	 var strDate = newDate + '';
	 return (strDate).substring(0, strDate.indexOf(' GMT')) + ampm;
 },
 
 whichBtnClickedToDisable: function(btn, view, type, _scope){
	var btnClicked = btn;
	var delayTime = Ext.isIE ? 5000 : 10;
	
	if(type == 'outsideHandler'){
		//view["btnClickedRef"] = btn.ref;
	 	//btnClicked.setDisabled(true);
	 	
	 	view["btnClickedRef"] = btn.ref;
		btnClicked.setDisabled(true);
	}
	else if(type == 'firstTimeHandler'){
		Ext.create('Ext.util.DelayedTask', function (args) {
			args.btnClicked.setDisabled(false);
			delete args.view.btnClickedRef;
	    }).delay(delayTime, null, null, [{btnClicked: btn, view: view}]);
	}
	else if(type == 'whenErrorFoundHandler'){
		////view["btnClickedRef"] = btn.ref;
	 	//btnClicked.setDisabled(false);
	}
	else if(type == 'insideHandler'){
		var btnClicked = _scope.view.down('button[ref='+_scope.view.btnClickedRef+']');        		
		btnClicked.setDisabled(false);
		delete _scope.view.btnClickedRef;
	}
	else if(type == 'whenErrorHandlerWithDelay'){
		view["btnClickedRef"] = btn.ref;
		btnClicked.setDisabled(true);
		
		Ext.create('Ext.util.DelayedTask', function (args) {
			args.btnClicked.setDisabled(false);
			delete args.view.btnClickedRef;
	    }).delay(10000, null, null, [{btnClicked: btn, view: view}]);
	}
 },
 
 timeLogger: function(type){
	 if(Constants.showConsole == true){
		 //return Ext.util.Format.date(new Date(), 'H:i:s-u');//H:i:s-u
		 return new Date(); 
	 }
 },
 
 setLayoutPosition: function(){
 	//TODO:- Fix - Replace vbox with absolute
 	if(Ext.isChrome){
 		return {type: Constants.layoutPosition, align:"stretch"}
 	}else{
 		return {type:"vbox", align:"stretch"}
 	}
 },
 
 setExtraBorder: function(type){
 	if(type !== undefined && (type).toUpperCase() == 'DONE'){
 		return '';//'border:1px solid green';
 	}
 	return '';//'border:1px solid red;';
 },
 
 reloadInboxGrid: function(reqId, actionTypePassed, taskId, fullObject){ 
	var inboxGrid = Ext.ComponentQuery.query('view_grid_dyngrid[ref=refIQDynGrid_requestorGridId]')[0];
	inboxGrid.getStore().proxy.extraParams = { 
		"requestJson": Ext.encode({"requestId": reqId, "action":actionTypePassed, "taskId": taskId, 'language': SMDU.gbl.userDetail.PREF_LANG}),
		'language': SMDU.gbl.userDetail.PREF_LANG
	};	
	inboxGrid.getStore().removeAll();
	inboxGrid.getStore().load();
 },
 
 isInManagerRoleFunction:function(){
	 var _isInManagerRole = false;
     var _inboxGridDynGdRef = Ext.ComponentQuery.query('view_inbox_inboxtabs')[0].down('view_grid_dyngrid');
     var  isInboxGrid = Ext.isEmpty(_inboxGridDynGdRef.swiftConfig.gridType) || _inboxGridDynGdRef.swiftConfig.gridType== 'smduinbox';
     if(!isInboxGrid){
     	_isInManagerRole = true;
     }
     return _isInManagerRole;
 },
 
 removeCommaFromAmount: function(value){
	 if(value == undefined){
		 return value;
	 }
	 else if(value == ""){
		 return value;
	 }
	 else{
		 var re = /,/gi;
		 var strNew = (value).replace(re, "");
		 return strNew;
	 }
 },
 
 replaceWildChars: function(strVal, encodeDecode){
	var str = strVal;
	var re, newStr, moreStr, rePer;
	if(!Ext.isEmpty(str)){
		if(encodeDecode == 'encode'){
			re = /&/gi;
			newStr = (str).replace(re, "_BLK_");
			rePer = /%/gi;
			newStr = (newStr).replace(rePer, '_PER_');
			moreStr = newStr;
		}
		else if(encodeDecode == 'decode'){
			re = /_BLK_/gi;
			moreStr = (str).replace(re, "&");
			
			rePer = /_PER_/gi;
			moreStr = (moreStr).replace(rePer, "%");
		}
	}
			
	//return Ext.htmlEncode(moreStr);
	return moreStr;
 },
 
 getAttachmentFileDataSelection: function(view){
	var _grid = view.down('view_grid_dyngrid');
	if(_grid == undefined){
		return []
	}else{
		var selMod = _grid.getSelectionModel().getSelection();
		var recLen = selMod.length;
		
		var attachmentGridPnl = []
		for(var i=0; i<recLen; i++){
			if(selMod[i].data.ID !== undefined){
				attachmentGridPnl.push(parseInt(selMod[i].data.ID));
			}   			
		}
		return attachmentGridPnl;
	}	
 },
 
 findSize: function (){
    if(window.ActiveXObject){
        var fso = new ActiveXObject("Scripting.FileSystemObject");
        var filepath = document.getElementById('fileInput').value;
        var thefile = fso.getFile(filepath);
        var sizeinbytes = thefile.size;
    }else{
        var sizeinbytes = document.getElementById('fileInput').files[0].size;
    }

    var fSExt = new Array('Bytes', 'KB', 'MB', 'GB');
    fSize = sizeinbytes; i=0;while(fSize>900){fSize/=1024;i++;}

    alert((Math.round(fSize*100)/100)+' '+fSExt[i]);
 },
 
 onClickConfigureEmailTemplate: function(btn, view, getFrmValues, _container, extraParam){	
	 
 	var me = this;
 	var container = _container || btn.up('container');
 	var chbx = container.query('checkbox');
 	var selectedEmailIdsMapping = {}
 	var selectedCount = 0;
 	 	
 	var onBehalfSOEID_ = '';
 	var secEmailAdd_ = '';
 	SMDU.gbl.requestorInfo.formType = view.swiftConfig.formType;
 	if(SMDU.gbl.requestorInfo.isCityEmployee == false && view.swiftConfig.formType == 'businessRequest'){
 		var tpuddForm = view.up('container').down('view_create_tpuddrequest[ref=refP2PBusReqScreen]').getForm();
 		var onBehalfSOEID_ = tpuddForm.findField('onBehalfSOEID').getValue();
 		var secEmailAdd_ = tpuddForm.findField('secondaryEmailAddress').getValue();
 		
 		//var soeid_ = tpuddForm.findField('soeid').getValue();
 	}
 	 	
 	var viewSupportObj = {
		"formType": view.swiftConfig.formType,
		"screenType": view.itemId,
		"supplierEmailAddress": btn.supplierEmailAddress,
		"secEmailAdd" : secEmailAdd_,
		"onBehalfSOEID": onBehalfSOEID_
		//,"soeid": soeid_
	}
 	if(btn.action == "btnEmailViewConfigureAction"){
 		viewSupportObj["fromEmailViewObject"] = extraParam;
 		selectedEmailIdsMapping = getFrmValues;
 	}else{
 		Ext.each(chbx, function(cb){
 	 		var _boxLabel = (cb.boxLabel).toLowerCase();
 	 		
 	 		if(_boxLabel == 'review complete' || _boxLabel == 'review cancel'){
 	 			//
 	 		}
 	 		else{
 	 			if(cb.getValue() === true){
 	 				selectedEmailIdsMapping[cb.name] = cb.boxLabel;
 	 	 			selectedCount++;
 	 			} 			
 	 		}
 	 	})
 	 	if(selectedCount === 0){
 	 		Ext.Msg.alert(lang_eng.alert_Text, lang_eng.selectPleaseAtleastOne);
 	 		return false;
 	 	}
 	}
 	
 	var templateWiz = Ext.create('widget.smdu_view_emailtemplate_TemplateWizard',{
 		template:{
 			selectedEmailIdsMapping: selectedEmailIdsMapping,
 			buttonClickRef: btn,
 			baseForm: view,
 			getFrmValues: getFrmValues,
 			viewSupportObj: viewSupportObj
 		}
	});
	templateWiz.show().center();		
 },
 
 resetCheckBoxItemsAfterEmailSend: function(passParam){
	 this.toggleViewEmailHyperlink(passParam.template.baseForm, 'refEmailTemplate');
	 
	 /*
	 passParam.template.baseForm.xtype;
	 passParam.template.baseForm.down('container[ref=refEmailTemplate]');
	 passParam.template.baseForm.ref;
	 */
 },
 
 toggleViewEmailHyperlink: function(formReference, elementItemId){ 
	//Note - this will show hyperlink under email template for View fields (EMAIL TEMPLATE)
	var getFrmValues = Ext.create('widget.bi_common_functions').getAllEmailDisplayFieldBoxOptions(formReference, 'refEmailTemplate');
	
	for(var prop in getFrmValues){
		if(getFrmValues[prop].value == 'on'){
			getFrmValues[prop].compRef.up('container').down('checkbox[name='+prop+']').setReadOnly(true);
		}
		getFrmValues[prop].compRef.up('container').down('displayfield[objectValue='+prop+']').setValue("[<a href='#' style='color:blue;'>"+lang_eng.view+"</a>]");
	}
	
	//console.log("formReference = "+formReference.xtype);
 },
 
 configViewEmailBtnCreation: function(emailList, newAry, _scope){
	 
 	for (var i = 0; i < emailList.length; i++) {
         var obj = {
             xtype: 'container',
             ref:'emailConfigEachRow',
             layout: {
                 type: "hbox",
                 align: 'stretch'
             },
             defaults: {
                 xtype: 'textfield',
                 _labelWidth: 200,
                 flex: 1,
                 margin: '5 7 5 7'
             },
             items: [{
             	xtype: 'displayfield',
                 value: "<span style='opacity:0.4 !important;'>["+lang_eng.view+"]</span>",
                 flex: 0.2,
                 action:'viewAlreadySendEmail',
                 labelWidth: 50,
                 objectValue: emailList[i].name,
                 objectValueRef: emailList[i],
                 name: 'viewField' + i,
                 listeners: {
                 	//element: 'el',
                 	scope: this,
                 	afterrender: function(cmp) { 
                 		var _this = cmp;
                 		cmp.getEl().on('click', function() { 
                 			var displayFieldRef = this.component;                    			
                 			var str = (displayFieldRef.value);
                 			
                 			console.log("log == "+str.indexOf('<a'))
                 			if(str.indexOf('href') > 0){
                 				var configureBtn = displayFieldRef.up('form').down('button[ref=refEmailConfigureBtn]');
                     			displayFieldRef.up('form').getController().callEmailViewObjectRefer({"action": "showAlreadySendEmails", viewObjRef: displayFieldRef, "configBtnRef": configureBtn});
                 			}                   			
                 		}); 
             	    }
                 }
             },{
                 xtype: 'checkbox',
                 objecType: 'templateName',
                 action:'viewAlreadySendEmail',
                 boxLabel: emailList[i].label, //_scope.getEmailURL(emailList[i].name, emailList[i]),
                 name: emailList[i].name
             }, {
                 xtype: 'displayfield',
                 value: Constants.URL_P2P_MAKER_EMAIL_1,
                 name: 'emailTemplate' + i,
                 hidden:true,                    
                 flex: 5
             }, {
                 xtype: 'checkbox',
                 boxLabel: lang_eng.reviewComplete,
                 objecType : 'reviewComplete',
                 name: 'emailTempReview' + i,
                 listeners:{
                 	change: "callEmailChangeEvent"
                 }
             }, {
                 xtype: 'checkbox',
                 hidden: false,
                 boxLabel:  lang_eng.reviewCancel,
                 objecType : 'reviewCancel', 
                 name: 'emailTempCancel' + i,
                 listeners:{
                 	change: "callEmailChangeEvent"
                 }
             }]
         }
         newAry.push(obj);
         delete obj;
     }
 	
 	newAry.push({
     	xtype:'button',
     	hidden:false,
     	margin:10,
     	text: lang_eng.configure,
     	cls: 'email-config-btn',
     	ref:'refEmailConfigureBtn',
     	align:'right',
     	iconCls: 'cls-btn-img-servicenow',        	
     	height: 30,
         minWidth: 90,
         action: 'btnEmailConfigureAction',
         handler: 'onClickConfigureEmailTemplate'
     });
     
     //newAry.push({ xtype: 'tbspacer', width: 20 });
     
     newAry.push({
     	xtype:'button',
     	hidden:false,
     	margin: '10 50',
     	text: lang_eng.saveEmailReview,
     	//cls: 'email-config-btn',
     	align:'right',
     	iconCls: 'cls-btn-img-submit',        	
     	height: 30,
         minWidth: 90,
         action: 'btnSaveEmailTemplateAction',
         handler: 'onClickSaveEmailTemplate'
     });
     
     newAry.push({
     	xtype: 'displayfield',
         value: '',
         name: 'emailTemplateError',
         ref: 'refEmailTemplateError',
         hidden: true
     });
 },
 
 onClickSaveEmailTemplate: function(btn, _isEmailReviewSuccess, view, me, _getFrmValues) { 
 	var getFrmValues = Ext.create('widget.bi_common_functions').getAllEmailCheckBoxOptions(view, _getFrmValues);
	
	var returnHandlerJSON = function(json){
 		if(json.success === false || json.success === "false"){
 			
 			//TODO:- Bypass the current error
 			//view.getController(view.controller.type).locSubmitP2PMakerForm(view, btn);
			Ext.Msg.alert(lang_eng.alert_Text, "INT022 failed, "+json.message); return false;
		}
		else{
			//var jsonObj = Ext.decode(json.data.data.response);
			var jsonObj = json.data.data.response;
			
			//Set isEmailReviewSuccess, from DB and update any local object
			if(_isEmailReviewSuccess == "isEmailReviewSuccess") {
				var field = view.getForm().findField('emailTemplateError');
				field.setValue("", false);
				field.hide();
				
				if(jsonObj.isEmailReviewSuccess == true) {
					view.getController(view.controller.type).locSubmitP2PMakerForm(view, btn);
				}
				else {
					var msg = '<span style="color:red;">'+lang_eng.emaiStatusAlertMsg+'</span>';
					//Ext.Msg.alert('Alert!', msg);						
					Ext.Msg.alert(lang_eng.alert_Text, lang_eng.alertFrmSubmit);						
					
					field.setValue(msg, false);
					field.show();
					field.focus();						
		    		return false;
				}
			}else{
				if(jsonObj.success == true || jsonObj.success == "true"){
					Ext.create('widget.bi_common_functions').waitMessage(jsonObj.message);
				}else{
					Ext.create('widget.bi_common_functions').waitMessage(jsonObj.message);
				}
			}
		}			
	};	
		
	var reqType = view.up('tabpanel').items.items[0].swiftConfig.formType;
	
	var _tpuddReq = {
		"p2pMaker":{
			"emailTemp"		: getFrmValues,
			"action"		: btn.action,
			"requestID"		: me.getRequestAndTaskIdFrmForm(view, 'requestId'),
			"taskId"		: me.getRequestAndTaskIdFrmForm(view, 'taskId'),
			"typeOF" 		: me.getAbbScreenType(reqType, view),
			"stepName"		: view.passedParams.submitStepName,
			"viewSupportObj" : { "formType" : view.swiftConfig.formType, "screenType"	: view.itemId }
		},
		 'language': SMDU.gbl.userDetail.PREF_LANG
	};
	
	if(_isEmailReviewSuccess == "isEmailReviewSuccess") {
		_tpuddReq.p2pMaker.emailTemp["isEmailReviewSuccess"] = "_BLANK";
	}
	
	var isPrm = {"requestJson": Ext.encode(_tpuddReq), 'language': SMDU.gbl.userDetail.PREF_LANG};	//INT022	
	var _URL = Constants.URL_GET_DASHBOARD_REVIEW_EMAIL_TEMPLATE;
	//smduCaspMakerSave, smduCaspCheckerSave, save - Casp Screens, anlstChkrSave	
	var isAllowedActions = !(btn.action == 'smduP2PCheckerNeedInfo' || btn.action == "returnToRequester" || btn.action == 'need info' || btn.action == 'anlstChkrNeedinfo' || btn.action == '_old_save' || btn.action == 'old_anlstChkrSave');
	if(isAllowedActions){
		Ext.create('widget.bi_common_functions').sendAjaxRequest(_URL, 'POST', returnHandlerJSON, isPrm, this);
	}else{
		view.getController(view.controller.type).locSubmitP2PMakerForm(view, btn);
	}	
 },
 
 callEmailChangeEventFunction: function(checkbox, newVal, oldVal, me, view) {
 	//Note:- Get Reference of container, that has all the checkbox under Email Template
 	var emailTemplateRef = me.getEmailMainReference();
 	var getFrmValues = Ext.create('widget.bi_common_functions').getAllEmailCheckBoxOptions(view, emailTemplateRef);    	
 	var _container = checkbox.up('container[ref='+emailTemplateRef+']'); 
 	
 	var str = checkbox.name;
 	strNew = str.substr(0, str.length-1);    	
 	var _count = str.slice(-1);
 	
 	if(strNew == "emailTempReview"){
 		if(_container.down("[name=emailTempReview"+_count+"]").getValue() == true){
 			_container.down("[name=emailTempCancel"+_count+"]").setValue(false)
 		}
 	}
 	else if(strNew == "emailTempCancel"){
 		if(_container.down("[name=emailTempCancel"+_count+"]").getValue() == true){
 			_container.down("[name=emailTempReview"+_count+"]").setValue(false)
 		}
 	}
 },
 
 getAllEmailCheckBoxOptions: function(view, emailTemplateRef){
 	var emailTmpPnl = view.down('container[ref='+emailTemplateRef+']');
 	var emailTmpPnlItems = emailTmpPnl.items.items;
 	var myAry = [];
 	var baseMyAry = {};
 	
 	for(var i=0; i<emailTmpPnlItems.length; i++){
 		if(emailTmpPnlItems[i].xtype !== 'button' && emailTmpPnlItems[i].xtype !== 'displayfield'){
 			var emailTmpPnlSingleItem = emailTmpPnlItems[i].items.items;
 			for(var m=0; m<emailTmpPnlSingleItem.length; m++){
         		var emailTmpPnlSingleItemObject = emailTmpPnlSingleItem[m];
         		
         		if(emailTmpPnlSingleItemObject.xtype !== 'displayfield'){
         			if(emailTmpPnlSingleItemObject.isHidden() == false){
             			var eName = emailTmpPnlSingleItemObject.name;
             			var eValue = (emailTmpPnlSingleItemObject.getValue() == true) ? "on" : "off";            			
             			baseMyAry[eName] = eValue;
             		}
         		}         		        		
         	}
 		}    		
 	}
 	return baseMyAry;
 },
 
 getAllEmailDisplayFieldBoxOptions: function(view, emailTemplateRef){
	var emailTmpPnl = view.down('container[ref='+emailTemplateRef+']');
 	var emailTmpPnlItems = emailTmpPnl.items.items;
 	var myAry = [];
 	var baseMyAry = {};
 	var displayViewFields = {};
 	
 	for(var i=0; i<emailTmpPnlItems.length; i++){
 		if(emailTmpPnlItems[i].xtype !== 'button' && emailTmpPnlItems[i].xtype !== 'displayfield'){
 			var emailTmpPnlSingleItem = emailTmpPnlItems[i].items.items;
 			for(var m=0; m<emailTmpPnlSingleItem.length; m++){
         		var emailTmpPnlSingleItemObject = emailTmpPnlSingleItem[m];
         		if(emailTmpPnlSingleItemObject.xtype !== 'displayfield'){
         			if(emailTmpPnlSingleItemObject.isHidden() == false){
             			var eName = emailTmpPnlSingleItemObject.name;
             			var eValue = (emailTmpPnlSingleItemObject.getValue() == true) ? "on" : "off";            			
             			baseMyAry[eName] = eValue;
             			
             			if(emailTmpPnlSingleItemObject.objecType !== undefined && emailTmpPnlSingleItemObject.objecType == "templateName"){
             				if(emailTmpPnlSingleItemObject.getValue() == true){
             					var eName = emailTmpPnlSingleItemObject.name;
                     			var eValue = (emailTmpPnlSingleItemObject.getValue() == true) ? "on" : "off"; 
                     			
                     			displayViewFields[eName] = {"value": eValue, compRef: emailTmpPnlSingleItemObject};
             				}             				
             			}
             		}
         		}         		        		
         	}
 		}    		
 	}
 	return displayViewFields;
 },
 
 generateRequestorNumber: function(reqTypeScreen) { 
	 	//console.log("reqTypeScreen ===> "+reqTypeScreen);
	 	var reqTypePre;
	 	if(reqTypeScreen == 'requestorGridId'){
	 		reqTypePre = "TD";
	 	}
	 	else if(reqTypeScreen == 'businessReqId'){
	 		reqTypePre = "BU";
	 	}
	 	else if(reqTypeScreen == 'escOpsReqId'){
	 		reqTypePre = "IO";
	 	}	 	
	 	else if(reqTypeScreen == 'employeeRequestId'){
	 		reqTypePre = "EM";
	 	}
	 	
		var dt = new Date();
		var tmpNum = reqTypePre + Ext.util.Format.date(dt, 'mdyisu');//Ymdhisu
		
		return tmpNum;
 },
	 
 getYearComboData: function(yearsVariation){
	if(!yearsVariation){
		yearsVariation = 2;
	}
	var year = (new Date()).getFullYear();
	var y = [];
	for(var i= year - yearsVariation; i<year+yearsVariation; i++){
		y.push([i,i])
	}
	return y;
 },
 
 getMonthComboData: function(){
	var m = [];
	for(var i=0; i<12; i++){
		m.push([i, Ext.Date.monthNames[i]]);
	}
	return m;
 },
 
 
 delayedTask: function (handleFunction, _delay) {
    Ext.create('Ext.util.DelayedTask', function () {
    	handleFunction();
    }).delay(_delay);
 },
 
 waitMessage: function(message){
	Ext.Msg.wait(message, lang_eng.alert_Text);
	window.setTimeout(function(){
		Ext.Msg.hide();
	}, 2000);	 
 },
 
 callDelayedTask: function(nodeName) {
	var me = this;
	
	return new Ext.util.DelayedTask(function(){
   	 	console.log('Delayed by 2 seconds');
   	 	return me.getAllStatusTogether(nodeName);
    }, me, [], null).delay(3000);
	 
 },
 
 getAllStatusTogether: function(nodeName, _obj){
	 var allStatus = ['REQUEST_STATUS', 'REQUESTER_STATUS', 'RESOLVER_STATUS'];
	 var aryList = [];
	 
	 for(var i=0; i<SMDU.gbl.meta.length; i++){
		 //console.log(SMDU.gbl.meta[i].category);
		 if( (SMDU.gbl.meta[i].category).toUpperCase() == 'REQUEST_STATUS' ||
			 (SMDU.gbl.meta[i].category).toUpperCase() == 'REQUESTER_STATUS' ||
			 (SMDU.gbl.meta[i].category).toUpperCase() == 'RESOLVER_STATUS')
		 {
			 if(SMDU.gbl.meta[i].data !== undefined){
				 var ms = SMDU.gbl.meta[i].data;
				 for(var k=0; k<ms.length; k++){
					 aryList.push(ms[k]);
				 }
			 }
		 }
	 }
	 
	 if(_obj.onlyData == true){
		 return aryList;
	 }
	 var _myStore = Ext.create('Ext.data.Store', {
	    autoLoad: true,
	    fields: ['id', 'name'],
	    data: aryList
	 });
	 delete _cmbVal;
	 return _myStore;
 },
 
 
 setToolTip: function(oElem, record, item, index, e, eOpts){
	return Ext.create("Ext.tip.ToolTip",{
        target:item,
        autoShow:true,
        trackMouse:true,
        html:record.data.name,
        hideDelay:0,
        showDelay:0
    });
 },

 isObjectEmpty: function( o ) {
     for ( var p in o ) { 
         if ( o.hasOwnProperty( p ) ) { return false; }
     }
     return true;
 },
 
 getStepAliasFromMetaData: function(nodeName, objList) {
	 var _cmbVal = [];
	 for(var i=0; i<SMDU.gbl.meta.length; i++){
	 	if( (SMDU.gbl.meta[i].category).toUpperCase() == nodeName.toUpperCase()){	  			
			if(SMDU.gbl.meta[i].data !== undefined){
				return SMDU.gbl.meta[i].data;				
			}
		}
	}
	return _cmbVal;
 },
 
 getStoreFromMetaData: function(nodeName) {
	 var _cmbVal = [];
	 
	 //if(nodeName == "ERROR DETAILS"){ debugger; }
	 if(SMDU.gbl.meta == undefined){ return []; }	 
	 for(var i=0; i<SMDU.gbl.meta.length; i++){
		//console.log("CAT -> "+SMDU.gbl.meta[i].category);
		var currCategory = (SMDU.gbl.meta[i].category).toUpperCase();
		var nodeName = nodeName.toUpperCase();
	 	if(currCategory === nodeName){
	 		//console.log("CAT -> "+SMDU.gbl.meta[i].category);
			if(SMDU.gbl.meta[i].data !== undefined){
				_cmbVal = SMDU.gbl.meta[i].data;
			}
		}
	}
	
	if(SMDU.gbl.userDetail.PREF_LANG !== undefined && SMDU.gbl.userDetail.PREF_LANG !== 'en'){
		//if(nodeName == 'REGION'){			
			for(var i=0; i<_cmbVal.length; i++){
				for(var prop in _cmbVal[i]) {
					if(prop === 'name'){
						_cmbVal[i]["name_en"] = _cmbVal[i][prop];
						delete _cmbVal[i].name;
						_cmbVal[i]["name"] = _cmbVal[i].name_InOtherLanguage;
					}
				}
			}
		//}
	}else{
		for(var i=0; i<_cmbVal.length; i++){
			for(var prop in _cmbVal[i]) {
				if(prop === 'name_en'){
					_cmbVal[i]["name"] = _cmbVal[i][prop];
					delete _cmbVal[i].name_en;
				}
			}
		}
	}
	
	//console.log(_cmbVal);
	var _myStore = Ext.create('Ext.data.Store', {
	    autoLoad: true,
	    fields: fields = ['id', 'name', 'name_InOtherLanguage', 'name_en'],
	    data: _cmbVal,
	    
	    sorters:{ property:'name', direction:'ASC'},
		remoteSort: false
	});
	delete _cmbVal;	
	return _myStore;
 },
 
 appLogOut: function(){
	var me = this;	
	var returnHandler = function(json){
		if(json.data.success == true){	
			if(window.location.href.indexOf('workspace') > -1){
				window.location = '../../index.jsp';
			}else{
				window.location = Constants.URL_APP_LOGOUT;
			}			
		}
	};
	var _url = Constants.URL_DASHBOARD_LOGOUT_URL;
	Ext.create('widget.bi_common_functions').sendAjaxRequest(_url, 'POST', returnHandler, {}, me);
 },
 
 verifyActiveSession: function(){
	 Ext.Ajax.request({
		url: Constants.URL_KEEP_SESSION_ALIVE,
		method: 'POST',
		timeout: Constants.ajaxReqTimeout,
		params:{'language': SMDU.gbl.userDetail.PREF_LANG},
		success: function(result) { 
			var json = Ext.decode(result.responseText);
			if(json.success === "true"){
				console.log('URL_KEEP_SESSION_ALIVE success!');
			}
		},
		failure: function() {
			console.log('URL_KEEP_SESSION_ALIVE fail!');
		}
	});
 },
 
 logoutFuntion: function(){	
	var me = this;
	var returnHandler = function(json){
		window.parent.location = document.referrer;		
		/*
		if(json.data.success == true){
			//window.parent.location.reload(true);
			window.top.location.reload(true);
			
			/*if(window.parent.location.href.indexOf('iQuery') > -1){
				_loc = 'iQuery';
			}else {
				_loc = 'portal';
			}
			window.parent.location = '../'+_loc+'/login.jsp';
			* /
		}*/
	};
	var _url = Constants.URL_APP_LOGOUT;//URL_DASHBOARD_LOGOUT_URL
	var parentPath = window.top.location.href;
	if(parentPath.indexOf('localhost') > -1 ){
		var msg = 'Session timeout, kindly re-login...';
		console.log(msg);	
		Ext.Msg.alert('Alert!', msg);		
	}else{
		Ext.create('widget.bi_common_functions').sendAjaxRequest(_url, 'POST', returnHandler, {}, me);
	}	
 },

 htmlEditorCharCount: function(editor, newVal, oldVal, _dvCmp){
	var regex = /(<([^>]+)>)/g,
	clearVal = newVal.replace(regex, ""),
	spaces = clearVal.match(/\s/g) ? clearVal.match(/\s/g).length : 0;
	//var parentCmp = Ext.getCmp(_parentCmp);
	var type = Ext.getCmp(_dvCmp);
	var _count = editor.maxLength - clearVal.length + spaces - spaces * 6;
	type.setValue('Remaining characters: '+_count);
	
	//editor.markInvalid('Exceeds max character length');
 },
  
 generateUniqueNumber: function() {
	/*var me = this;//{"success": "true","Time":"2016/08/08 16:03:01 508"}
	var returnHandlerJSON = function(json){
		if(json.success == "true"){
			var dt = new Date(json.milliSeconds);
			return "REQ"+Ext.util.Format.date(dt, 'mdYisu');
		}else{
			var dt = new Date();
			return "REQ"+Ext.util.Format.date(dt, 'mdYisu');//Ymdhisu
		}
	}	
	var _URL = Constants.URL_METADATA_GET_CURR_DATETIME;
	me.sendAjaxRequest(_URL, 'POST', returnHandlerJSON, {}, this);*/
	//return SMDU.gbl.meta.timestamp;
	
	
	var dt = new Date();
	return "REQ"+Ext.util.Format.date(dt, 'mdYisu');//Ymdhisu
	
 },
 
 generateTaskId: function(_number) {
	 return _number.substr(6);
 },
 
 validateFormFields: function(aryList, me){
	Ext.each(aryList, function(element) {
	    field = me.getForm().findField(element);
	    
	    if(field.setFieldLabel){	    	
	    	//console.log(field.name+" - "+(field.fieldLabel).indexOf("*"));	    	
	    	if((field.fieldLabel).indexOf("*") > 0){
	    		return;
	    	}
	    	field.setFieldLabel(field.fieldLabel+'<span style="color:red;font-size:14px;font-weight:bolder;"> *</span>');
		    //if(Ext.isEmpty(field.getValue())){
		    	field.allowBlank = false;		    	
			    //field.markInvalid('This field is mandatory.');
		   // }	
	    }
    })		  
 },
 
 recallMetadataService:function(){//Not in use
	Ext.Ajax.request({
		url: Constants.URL_GET_META_DATA,
		method: 'POST',
		scope: this,
		params: {},
		success: function(response_) {
			SMDU.gbl.meta = Ext.decode(Ext.decode(response_.responseText).data.data.metadata);
		},
		failure: function(response_) {
			console.error('Server request encountered an error. Please contact admin. ', response_);
		}
	});
 },
 
 //Main Send Ajax Request
 sendAjaxRequest: function(_url, _method, _handlerReturn, _params, _scope){
	var _this = this;
	var view_homecontainer = this.getHomeContainerLoader();
	
	//console.log("URL - "+_url.substr(_url.lastIndexOf("?")));
	//console.log("URL send - "+_url);
	
	if(Constants.EVERY_AJAX_REQ_RES_LOG == true){
		Ext.create('widget.bi_common_functions').showSlownessLogs('SendAjaxRes - Request Send', 'Start', _url, 'YES');
	}
		
    Ext.Ajax.request({
        method: _method || 'POST',//POST, GET
    	//method: 'POST',
        url: _url,
        timeout: Constants.ajaxReqTimeout,//(changed from 30's to 60's)
        waitTitle: 'Connecting',
        waitMsg: 'Sending data...',
        scope: _scope,
        success: function(result, request) {
        	var ms = new Date();
            if((result.responseText).indexOf('SiteMinder') > -1){
				Ext.Msg.alert(lang_eng.alert_Text, result.responseText);
				//Ext.get('apploading').dom.innerHTML = response_.responseText;
				return false;
			}
            //Single Sign-On, login page
            if(result.responseText.indexOf('Welcome to') > -1){
            	console.log('Successfully Logged Out - ' + ms);
            	window.top.location.reload(true);
				return false;
			}
            
            //Single Sign-On, Successfully Logged Out - When Cookie gets attached to the URL
            if(result.responseText.indexOf('Not Implemented') > -1){
            	console.log('Successfully Logged Out - ' + ms);
            	window.top.location.reload(true);
				return false;
			}
            
            //Single Sign-On, Successfully Logged Out
            if(result.responseText.indexOf('Successfully Logged Out') > -1){
            	console.log('Successfully Logged Out - ' + ms);
            	window.top.location.reload(true);
				return false;
			}
            //CWM WebApp Portal
            if(result.responseText.indexOf('<form action') > -1){
				Ext.Msg.alert('Alert!', 'Session expired, kindly login again. - ' + ms);
				return false;
			}
            else{
				var jsonData = Ext.decode(result.responseText);
	            if(jsonData.success === false || jsonData.success === "false"){				
					Ext.Msg.alert(lang_eng.alert_Text, jsonData.message); 
					view_homecontainer.setLoading(false);
					if(_scope.unmask !== undefined){_scope.unmask();}					
					return false;
				}
	            
	            if(Constants.EVERY_AJAX_REQ_RES_LOG == true){
	            	Ext.create('widget.bi_common_functions').showSlownessLogs('SendAjaxRes - Response Received', 'End', _url, 'YES');
	        	}	            
	            
	            return _handlerReturn(jsonData, _scope);
			}
        },
        failure: function(result, request) {
            var jsonData = Ext.decode(result.responseText);
            return _handlerReturn(jsonData, _scope);
        },
        headers:{'dev':'nahb_yajnas', 'language': SMDU.gbl.userDetail.PREF_LANG},
        params: _params
    });	
 },
 
 browserURL: function(){
	return window.parent.location.href;
 },

 getURLParams: function(name, url){	
	 	//console.log(location.href+"  & "+window.parent.location.href);
	 	if (!url) url = this.browserURL();
		name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
		var regexS = "[\\?&]"+name+"=([^&#]*)";
		var regex = new RegExp( regexS );
		var results = regex.exec( url );
		return results == null ? null : results[1];
 },

  redirectURL: function(){
		var _localPath = '';		
		var _fullpath = this.browserURL();
		var _path = _fullpath.substr(0, _fullpath.indexOf("?"));
		
		if(Ext.isEmpty(_path)){
			_localPath = _fullpath.replace("direct", "index");
		}else{
			_localPath = _path.replace("direct", "index");
		}
		return _localPath;		
  },

  localSession: function(key, value){
		if(typeof(Storage) !== undefined){
			//Make sure value is always in lowercase;
			localStorage.setItem(key, value);
		}
  },
  
  changeUrl : function(page, url){
	  var origURL = url || window.top.location.href.split('?')[0]; 
	  var history = window.top.history;
	  var _url = url || origURL;
	  var page = page || "page";
	  console.log("changeUrl - " + origURL);
	  if(typeof (history.pushState) != 'undefined'){
		  var obj = {"Page": page, "Url": _url}; 
		  history.pushState(obj, obj.Page, obj.Url);
	  }else{
		  window.location.href = origURL;
	  }
  },
  
  prepareExcelDownload: function(paramValues, _url, myParams){ 
	var me = this;
	var _param = {};
	var _myParam = [];
	var str = "";
	var vals = paramValues;
	for(var i in vals){
		if(vals[i] !== ''){
			_param[i] = vals[i];
		}
	};
	var i = 1;
	for(var prop in _param){
		if(i==1){ connV = "?"; }else{ connV = "&"; }
		str += connV+prop+"="+_param[prop]; i++;
		_myParam.push('{'+prop+':'+_param[prop]+'}');
	}
	
	me.downloadFile(_url, _param, myParams);
	//Ext.dom.Query.selectNode("iframe[name=docsFileIframe]").src = _url + str;
 },
 
 downloadFile: function (url, params, myParams) { 
	 
	 var _baseURL = '';
	 _baseURL = url + myParams + "&id=" + Math.random();
	 
	 if(Ext.fly('hiddenform-form') !== null) {
		 Ext.fly('hiddenform-form').remove();
	 }
	 
     var body = Ext.getBody(),
         frame = body.createChild({
             tag: 'iframe',
             cls: 'x-hidden',
//             id: 'hiddenform-iframe',
             name: 'hiddenform-iframe'
         }),
         
         form = body.createChild({
             tag: 'form',
             method: 'POST',
             cls: 'x-hidden',
             //id: 'hiddenform-form',
             name: 'hiddenform-form',
             action: _baseURL,
             target: 'iframe'
         });
     for (var prop in params) {
     	form.createChild({
             tag: 'input',
             type: 'hidden',
             cls: 'x-hidden',
             //id: 'hiddenform-' + prop,
             name: prop,
             value: params[prop]
         });
     	//console.log(prop+" = "+params[prop]);
     }
     //var str = myParams.data;
     //var repStr = str.replace(/"/g, '\'');
     
     //console.log(_baseURL);
     //console.log('----->'+repStr);//repStr
     //debugger;
     
     form.createChild({
	     tag: 'input',
	     type: 'hidden',
	     cls: 'x-hidden',
	     //id: 'hiddenform-textarea',
	     name: 'jsonData',
	     value: myParams//repStr
	 });
     
     form.dom.action = _baseURL;
     //console.log('CSV URL - '+form.dom.action);
     
     form.dom.submit();
     console.log('Form submitted, values passed to backend.')
     
     
     //body.dom.remove();
     //debugger;
     //Ext.fly('hiddenform-form').remove();
     
     delete body, frame, _baseURL, form;
     
     
     new Ext.util.DelayedTask(function(){
//    	 Ext.fly('hiddenform-form').dom.action = '';
     }, this, [], null).delay(550);
     
     return frame;
 },
 
 downloadExcelFile: function (_url, _params, _isType) {

   var body = Ext.getBody(),
       frame = body.createChild({
           tag: 'iframe',
           cls: 'x-hidden',
           id: 'hiddenform-iframe',
           name: 'iframe'
       }),

       form = body.createChild({
           tag: 'form',
           method: 'POST',
           cls: 'x-hidden',
           id: 'hiddenform-form',
           action: _url,
           target: 'iframe'
       });
   
   if(_isType === 'onTheFly'){
	   var str = _params.data;
	   var repStr = str.replace(/"/g, '\'');
	   form.createChild({
		     tag: 'input',
		     type: 'hidden',
		     cls: 'x-hidden',
		     id: 'hiddenform-textarea',
		     name: 'data',
		     value: repStr
		 });
   }
   
   for (var i in _params) {
       if (Ext.isArray(_params[i])) {
           for (var j = 0; j < _params[i].length; j++) {
               form.createChild({
                   tag: 'input',
                   type: 'hidden',
                   cls: 'x-hidden',
                   id: 'hiddenform-' + i,
                   name: i,
                   value: _params[i][j]
               });
           }
       } else {

           form.createChild({
               tag: 'input',
               type: 'hidden',
               cls: 'x-hidden',
               id: 'hiddenform-' + i,
               name: i,
               value: _params[i]
           });
       }

   }

   form.dom.action = _url;
   
   form.dom.submit();
   delete body, frame, _url, form;

   new Ext.util.DelayedTask(function(){
  	 Ext.fly('hiddenform-form').dom.action = '';
   }, this, [], null).delay(550);
   
   return frame;
},

getPrferedLanguageFromBackend : function(loadedFromApp) {
	var me = this;		
	var lang = '';
	Ext.Ajax.request({
		url: Constants.URL_PREFERED_LANG_FROM_BACKEND, //Get Current Time
		method: 'POST',
		timeout: Constants.ajaxReqTimeout,
		scope: this,
		async:false,
		params: {'language': SMDU.gbl.userDetail.PREF_LANG},
		success: function(response_) {
			if(response_.status == '200'){					
				if(loadedFromApp && loadedFromApp.isSessionActive(response_) == true){
					var json = Ext.decode(response_.responseText);
					console.log(json);
					lang = json.lang ? json.lang : '';
				}
			}else{
				return ""
			}
		},
		failure: function(response_) {
			var json = Ext.decode(response_.responseText);
			console.log(json);
			return ""
		}
	});
	return lang;

}
  
 
});
