function AppConstants() {
    this.DATASET_SCREEN_FLEX=2.5;
    this.DATAPROFILE_SCREEN_FLEX=6;
    this.GEN_CDN = 'https://cdn.uat.citigroup.net:4003';

    //document.domain="sit.citigroup.net" 
    
    //this.URL_STUB_BASE = '../smdu/data-stub';
    //this.URL_SERVER_BASE = '../cwmcommon';
    //this.URL_SERVER_BASE_WRAP = '../smdu'; 
      
    //-========[Local Development]=======\\
    this.URL_STUB_BASE = 'http://localhost:8080/smduweb/smdu/data-stub';
    this.URL_SERVER_BASE = 'http://localhost:8080/smduweb/smdu';
    this.URL_SERVER_BASE_COMMON = 'http://localhost:8080/smduweb/cwmcommon';
    this.URL_SERVER_BASE_WRAP = 'http://localhost:8080/smduweb/smdu'; 
    
    // <<Copy from here>> 
    this.SUFFIX = '.json';
    this.URL_DEFAULT_PAGE = './dashboardtiles.jsp';
    this.URL_DEFAULT_DIR = '../SMDU';
    this.URL_DEFAULT_MODE = '__MODE__=fromIFrame';
    	 
    this.URL_APP_LOGOUT = '../../sminfoagent/forms/logout.html?portal=new';
    
    //Show buttons like Save/Submit/Cancel in the portal with true else make it false
    this.ISLOCAL = true; 
    this.ISJSONMODE = '&x-method-override=POST&accept=application/json';
    
    this.URL_METADATA_GET_CURR_DATETIME = this.URL_SERVER_BASE_WRAP + '/getServerUserDetails';
    //this.URL_METADATA_GET_CURR_DATETIME = this.URL_SERVER_BASE + '/getServerCurrentTime';
    
    this.LANG_LIST_TO_SUPPORT = {
    	"ENGLISH" : "en",
    	"SPANISH" : "es",
    	"PORTUGUESE" : "pt_BR",
    	"MANDARIN" : "zh_CN",
    	"KOREAN" : "ko",
    	"TRADITIONAL CHINESE" : "zh_TW",
    	"JAPANESE" : "ja"
    };
    
    //PORTUGUESE (Brazil) - pt_BR, PORTUGUESE (Portugal) - pt_PT
    
    //Match Details - Grid
    this.isMethod = "POST";//Write in Cap letters, GET OR POST
    this.ajaxReqTimeout = 60000;//(changed from 30's to 60's)
    this.sessionTimeout = 1000 * 60 * 25;// 30 minutes of inactivity allowed (1 min lesser)
    this.sessionTimeoutBeforeAlert = 60 * 5;
    this.sessionTimeoutLog = false;
    this.enableSessionTimeout = true;
    this.maxChars = "4000"; 
    this.maxNoteChars = "250";
    this.layoutPosition = "absolute"; //TODO:- vbox, absolute
    
    
    this.isLocalMethod = "POST";
    //this.alertFrmSubmit = lang_eng.alertFrmSubmit;
    //this.alertFrmSubmitMask = lang_eng.alertFrmSubmitMask;  
    
    this.URL_KEEP_SESSION_ALIVE = this.URL_SERVER_BASE_WRAP + '/getServerUserDetails';
    
    this.alertYetToImplement = "To be Implemented";
    this.editableFieldColor = 'firebrick';
    this.defaultLabelColor = 'black';
    this.EMAIL_NOT_IMPLEMENTED = "<span style='color:red;'>&nbsp;"+this.alertYetToImplement+"</span>";
    this.EMAIL_NOT_IMPLEMENTED_DONE = "&nbsp;";
    //this.SHOW_SINGEVIEW_BUTTON = "true"; //true - hide button and false - show button
    this.IS_EMAIL_VIEW_LINK_ACTIVE = true;
    
    //Write in Cap letters, GET OR POST, finally it should go with POST
    this.isMethodForThis = this.isMethod;
    this.matchDetailsNewService = true; //true, false [single service - getMatch]
    this.docUploadNewService = true; //true, false [single service - getAllDocuments]
    
    this.dynamicFormCreation = true;//true - hide, false - show
    
    this.RUN_INBOX_BEFORE_LOAD = true; 
    this.showConsole = false; //show logs in Action Type
    
    this.NOTE_EMPLOYEE_REQ_RORM = "<span style='color:blue;'>The below list of countries where SSB is NOT available.  If country/region is selected is from the list provided this field will NOT be seen, reason for request will be SSB not available.  If Country/Region selected is NOT part of the list Olga sent this field will be displayed and WILL BE Mandatory."+
    	"<ul class='list'><li>Congo</li><li>Gabon</li><li>Cameroon</li><li>Jersey</li><li>Jordan</li><li>Panama</li></ul></span>";
    
    this.URL_DEFAULT_REQUEST_PRESET = "EM1201173752966";// (default - _BLANK) EM0915175512708, BU0801173229025
    /*
	    EM1010174438302, EM1010174729074, EM1011171204839, BU1014171424096, BU0819170552441
	    BU0923175927171 - Bus Req (New) BU1024172909913 / BU1024173044513
	    IO0926172826797 - Esc Req (Bulk)
	    IO0926170246300 - Esc Req (Maintenance - Minor)
	    EM0926172020414 - Emp Req
	    EM0912174456775 - Casp Maker - BU0819170552441
	    BU1121171423492 - P2P Checker
	    EM1128170334818 - Emp Req 
    */
    this.delayForIESinglView = 2500;
    this.delayForOtherSinglView = 1000;
    
    this.URL_EMPLOY_REQ_SETUP_NOTE = "<span style='color:blue;'>Note:- Please enter the full bank address including city, state, zip code and country</span>"; 						
	
    //NEW START
    //NEW END
    
    //this.URL_EMAIL_DL_CREATION_ADMIN = this.URL_STUB_BASE+"/emailtemp/emailDLAdmin.json";
    this.URL_EMAIL_DL_CREATION_ADMIN = this.URL_SERVER_BASE_WRAP + '/callBPMService?interfaceID=INT024';
    
    
    //Out of Office
    this.URL_INSERT_OOO_DATA = this.URL_SERVER_BASE + '/callBPMService?interfaceID=INT025';
    this.URL_SELECT_OOO_DATA = this.URL_SERVER_BASE + '/callBPMService?interfaceID=INT026';
    
    this.URL_DASHBOARD_DOWNLOAD_DETAILED_REPORT = this.URL_SERVER_BASE_WRAP +'/getDetailReportCSV';
    
    this.PERDAY_REPORT_LOCAL = false;
    if(this.PERDAY_REPORT_LOCAL == true){
    	this.URL_DASHBOARD_DOWNLOAD_PER_DAY_REPORT = this.URL_STUB_BASE+"/dashboard/successResponse.json";    	
    }else{
    	this.URL_DASHBOARD_DOWNLOAD_PER_DAY_REPORT = this.URL_SERVER_BASE_WRAP +'/offlineDataDumpReport';
    }
        
    this.URL_DASHBOARD_LOGOUT_URL = this.URL_SERVER_BASE_COMMON +'/logout';
    this.URL_GET_COMMODITIES_LINK = "http://policies.citigroup.net/cpd/download?name=documents/CEMP+Restricted+Commodity+Owners+and+Liaisons_09021b5f80018313.pdf";
    
    this.P2PMAKER_SCREEN_OLD = {
    	"emailTempBusiness" : "https://otshare.nam.citi.net/sites/ESCSMDU/Shared Documents/SMDU P2P GLOBAL/EMAIL BUSINESS TEMPLATES/EMAIL CITI BUSINESS USER_STANDARD TEMPLATE _DRAFT ONLY.msg",
    	"emailTempSupplier" : "https://otshare.nam.citi.net/sites/ESCSMDU/Shared Documents/SMDU P2P GLOBAL/EMAIL SUPPLIER TEMPLATES/EMAIL SUPPLIER STANDARD TEMPLATE _DRAFT ONLY.msg",
    	"emailTempTaxReview" : "https://otshare.nam.citi.net/sites/ESCSMDU/Shared Documents/SMDU P2P GLOBAL/TAX REVIEW TEMPLATES/CWM REQUEST ID XXXXXXXX - REQUIRES TAX APPROVAL - SUPPLIER NAME XXXXXXXX.oft",
    	"emailTempFinReview" : "https://otshare.nam.citi.net/sites/ESCSMDU/Shared Documents/SMDU P2P GLOBAL/FINANCE REVIEW TEMPLATES/CWM REQ ID - XXXXXXXXXXXX - RESTRICTED SIC TO COMMIDTY APPROVAL REQUEST - SUPPLIER .oft",    	
    	"emailTempEinvReq" : "#",
    	"emailTempSourcing" : "https://otshare.nam.citi.net/sites/ESCSMDU/Shared Documents/SMDU P2P GLOBAL/EMAIL TO SOURCING MANAGER/EMAIL SOURCING MANAGER - STANDARD TEMPLATE - DRAFT ONLY.msg",
    	"emailTempABC" : "https://otshare.nam.citi.net/sites/ESCSMDU/Shared Documents/SMDU P2P GLOBAL/ABandC ESCALATION TEMPLATE/P2P ABC Pre-Onboarding Risk Factor Review for Name of ETP.oft"
    };
    
    this.P2PMAKER_SCREEN = {
    	"emailTempBusiness" : "#",
    	"emailTempSupplier" : "#",
    	"emailTempTaxReview" : "#",
    	"emailTempFinReview" : "#",    	
    	"emailTempEinvReq" : "#",
    	"emailTempSourcing" : "#",
    	"emailTempABC" : "#"
    };
    
    //More Items
    //this.URL_BUSINESS_LINK_ACTIONTYPE_HREF_OLD = "https://otshare.nam.citi.net/sites/ESCSMDU/_layouts/15/start.aspx#/Shared%20Documents/Forms/AllItems.aspx?RootFolder=/sites/ESCSMDU/Shared%20Documents/GLOBAL%20SUPPLIER%20MASTER%20DATA%20UNIT%20-%20%20OPERATING%20PROCEDURES%26FolderCTID=0x012000E8B59F7F0A99644C82634C0CD795FEBB%26View=%7b77D71966-F54C-406F-A316-E5E415349606%7d";
    //this.URL_BUSINESS_LINK_ACTIONTYPE_HREF_OLD2 = "https://commercial.collaborationtools.consumer.citigroup.net/sites/tpu/TPU%20External/TPU%20SMDU/Supporting%20Documents/SMDU%20Supporting%20Document%20Matrix.xlsx";
    
    this.URL_BUSINESS_LANGUAGE_NOTE = "<span style='font-size:11px;color:blue;'>Please note that in case supporting documents are in the following languages: Hebrew, Greek, Urdu, Thai and Vietnamese it is required to use a Supplier Creation Translation form to submit a request otherwise we won't be able to process it.</span>";
    
    this.URL_CASP_MAKER_NOTE = '<span style="font-size:11px; color:blue;">By selecting "Yes" on the below question, an email template will be displayed. All attachments associated with the request will automatically be attached to the email template, and you must ensure you remove attachments that are not needed or that should not be shared. Once the email template is displayed the SMDU CASP Maker will have the ability to modify who the recipient of the email will be (either internally or externally) and will also have the ability to modify the body of the email. Once a response is recieved from the recipient of the email please select “Review Complete” or "Review Cancel" to place item back into your Worklist. </span>';
    
    //Email Template - SMDU P2P Maker

    this.maxCharsMsg = ' (<span style="color:blue;font-size:11px;">Max Chars :- '+this.maxChars+'</span>)';
    this.maxCharsNoteMsg = ' (<span style="color:blue;font-size:11px;">Max Chars :- '+this.maxNoteChars+'</span>)';
    
    //Verbiage on Email for below screens
    this.URL_VERBIAGE_EMAIL_ANA_CHECKER = '<span style="font-size:11px;color:blue;">If an email needs to be sent to one of the groups listed below, select the checkbox next to appropriate group and click on the "Configure" button. You have the ability to select multiple emails at a time. Once you have clicked on "Configure", the email template for the option(s) selected will be displayed. All attachments associated with the request will automatically be attached to the email template, and you must  ensure you remove attachments that are not needed or that should not be shared. Once the email template is displayed the TPU Screening Analyst will have the ability to modify who the recipient of the email will be (either internally or externally) and will also have the ability to modify the body of the email. Once a response is recieved from the recipient of the email please select "Review Complete" or "Review Cancel" to place item back into your Worklist.</span>';
    this.URL_VERBIAGE_EMAIL_ANA_MAKER =   '<span style="font-size:11px;color:blue;">If an email needs to be sent to the group listed below, select the checkbox next to appropriate group and click on the "Configure" button. Once you have clicked on "Configure", the email template for the option selected will be displayed. All attachments associated with the request will automatically be attached to the email template, and you must  ensure you remove attachments that are not needed or that should not be shared. Once the email template is displayed the TPU Screening Analyst will have the ability to modify who the recipient of the email will be (either internally or externally) and will also have the ability to modify the body of the email. Once a response is recieved from the recipient of the email please select "Review Complete" or "Review Cancel" to place item back into your Worklist.</span>';
    this.URL_VERBIAGE_EMAIL_P2P_MAKER = '<span style="font-size:11px;color:blue;">If an email needs to be sent to one of the groups listed below, select the checkbox next to appropriate group and click on the "Configure" button. You have the ability to select multiple emails at a time. Once you have clicked on "Configure", the email template for the option(s) selected will be displayed. All attachments associated with the request will automatically be attached to the email template, and you must  ensure you remove attachments that are not needed or that should not be shared. Once the email template is displayed the SMDU P2P Maker will have the ability to modify who the recipient of the email will be (either internally or externally) and will also have the ability to modify the body of the email. Once a response is recieved from the recipient of the email please select "Review Complete" or "Review Cancel" to place item back into your Worklist.</span>';
    
    this.URL_VERBIAGE_EMAIL_CASP_MAKER = '<span style="font-size:11px;color:blue;">If an email needs to be sent to the group listed below, select the checkbox next to appropriate group and click on the "Configure" button. Once you have clicked on "Configure", the email template for the option selected will be displayed. All attachments associated with the request will automatically be attached to the email template, and you must  ensure you remove attachments that are not needed or that should not be shared. Once the email template is displayed the TPU Screening Analyst will have the ability to modify who the recipient of the email will be (either internally or externally) and will also have the ability to modify the body of the email. Once a response is recieved from the recipient of the email please select “Review Complete” or "Review Cancel" to place item back into your Worklist.</span>';
    
    
    this.URL_CASP_MANAGER_EMAIL_1 = '<span style="font-size:11px;color:blue;">If an email needs to be sent to the group listed below, select the checkbox next to appropriate group and click on the "Configure" button. Once you have clicked on "Configure", the email template for the option selected will be displayed. All attachments associated with the request will automatically be attached to the email template, and you must  ensure you remove attachments that are not needed or that should not be shared. Once the email template is displayed the SMDU CASP Manager will have the ability to modify who the recipient of the email will be (either internally or externally) and will also have the ability to modify the body of the email.</span>';
    this.URL_P2P_MANAGER_EMAIL_1 = '<span style="font-size:11px;color:blue;">If an email needs to be sent to the group listed below, select the checkbox next to appropriate group and click on the "Configure" button. Once you have clicked on "Configure", the email template for the option selected will be displayed. All attachments associated with the request will automatically be attached to the email template, and you must  ensure you remove attachments that are not needed or that should not be shared. Once the email template is displayed the SMDU P2P Manager will have the ability to modify who the recipient of the email will be (either internally or externally) and will also have the ability to modify the body of the email.</span>';
    
    
    this.URL_VERBIAGE_EMAIL_TPU_TEAMLEAD = '<span style="font-size:11px;color:blue;">If an email needs to be sent to one of the groups listed below, select the checkbox next to appropriate group and click on the "Configure" button. You have the ability to select multiple emails at a time. Once you have clicked on "Configure", the email template for the option(s) selected will be displayed. All attachments associated with the request will automatically be attached to the email template, and you must  ensure you remove attachments that are not needed or that should not be shared. Once the email template is displayed the TPU Screening Analyst will have the ability to modify who the recipient of the email will be (either internally or externally) and will also have the ability to modify the body of the email. Once a response is recieved from the recipient of the email please select "Review Complete" or "Review Cancel" to place item back into your Worklist.</span>';
    
    //this.URL_VERBIAGE_EMAIL_P2P_MAKER = '<span style="font-size:11px;color:blue;"></span>';
    /*
    this.URL_MATCHDETAILS_POP_MATCH_GETLIST = this.URL_STUB_BASE + '/matchDetails/getMatch.json';
    this.URL_MATCHDETAILS_POP_LINK_INSERT = this.URL_STUB_BASE + '/matchDetails/insertMatchLink.json';
    this.URL_MATCHDETAILS_POP_LINK_GETLIST = this.URL_STUB_BASE + '/matchDetails/getMatchLinks.json';
    this.URL_MATCHDETAILS_POP_LINK_DELETE = this.URL_STUB_BASE + '/matchDetails/deleteMatchLink.json';
    this.URL_MATCHDETAILS_POP_MATCH_INSERT = this.URL_STUB_BASE + '/matchDetails/insertMatch.json';
    this.URL_MATCHDETAILS_POP_MATCH_DELETE = this.URL_STUB_BASE + '/matchDetails/deleteMatch.json';
    this.URL_MATCHDETAILS_POP_MATCH_DELETE_BY_STEPNAME = this.URL_STUB_BASE + '/matchDetails/deleteMatchByStepNameReqId.json';
    this.URL_MATCHDETAILS_POP_MATCH_UPDATE = this.URL_STUB_BASE + '/matchDetails/updateMatch.json';
    this.URL_MATCHDETAILS_MATCH_DELETE_FILE = this.URL_STUB_BASE + '/matchDetails/deleteFile.json';
    */
    this.URL_GET_DASHBOARD_SUBMIT_REQUESTOR_FORM_TEMP = this.URL_STUB_BASE + '/matchDetails/submitForm.json';

    //this.URL_MATCHDETAILS_POP_MATCH_DETAILS_GET_UPLOADEDFILES = this.URL_STUB_BASE + "/matchDetails/getAllDocs.json";
    this.URL_MATCHDETAILS_POP_MATCH_DETAILS_GET_UPLOADEDFILES_NEW = this.URL_SERVER_BASE_WRAP+"/getAllDocuments";
    
    this.URL_REQUESTOR_FORM_JUSTIFICATION_HREF = "https://technology.home.citi.net/sites/ESC/MarketIntel/Market%20Intel/Procurement%20Best%20Practice/Global%20Payment%20Terms%20Matrix/Payment%20Terms%20Inventory%20Matrix.xlsx";
    //<a href="'+this.URL_REQUESTOR_FORM_JUSTIFICATION_HREF+'" target="_blank">Click here</a> </span>
    
    
    //12May
    
    
    //After integration with backend    
    this.URL_MATCHDETAILS_POP_MATCH_GETLIST = this.URL_SERVER_BASE_WRAP + '/getMatch';
    this.URL_MATCHDETAILS_POP_LINK_INSERT = this.URL_SERVER_BASE_WRAP + '/insertMatchLink';
    this.URL_MATCHDETAILS_POP_LINK_GETLIST = this.URL_SERVER_BASE_WRAP + '/getMatchLinks';
    this.URL_MATCHDETAILS_POP_LINK_DELETE = this.URL_SERVER_BASE_WRAP + '/deleteMatchLink';
    
    this.URL_MATCHDETAILS_POP_MATCH_INSERT = this.URL_SERVER_BASE_WRAP + '/insertMatch';
    this.URL_MATCHDETAILS_POP_MATCH_DELETE = this.URL_SERVER_BASE_WRAP + '/deleteMatch';
    this.URL_MATCHDETAILS_POP_MATCH_DELETE_BY_STEPNAME = this.URL_SERVER_BASE_WRAP + '/deleteMatchByStepNameReqId';
    this.URL_MATCHDETAILS_POP_MATCH_UPDATE = this.URL_SERVER_BASE_WRAP + '/updateMatch';
    this.URL_MATCHDETAILS_POP_MATCH_FIE_DELETE = this.URL_SERVER_BASE_WRAP +'/deleteFile';
    
    
    //ALL SERVICE CALLS
    this.URL_GET_DASHBOARD_SUBMIT_REQUESTOR_FORM = this.URL_SERVER_BASE_WRAP + '/callBPMService?interfaceID=INT001';
    this.URL_GET_DASHBOARD_MODIFY_REQUESTOR_FORM = this.URL_SERVER_BASE_WRAP + '/callBPMService?interfaceID=INT013';
    
    this.URL_GET_DASHBOARD_MANAGER_ROLE = this.URL_SERVER_BASE_WRAP + '/callBPMService?interfaceID=INT014';
    
    if(this.isMethod == "GET"){
    	this.URL_GET_DASHBOARD_RETRIEVE_REQUESTOR_FORM = this.URL_STUB_BASE+'/local/retrieveRequestorForm_3.json';
    	this.URL_DASHBOARD_INBOX_GRID = this.URL_STUB_BASE+'/dashboard/inbox.json';
    	this.URL_DASHBOARD_GROUP_UNITS = this.URL_STUB_BASE+"/groupunit.json";
    	this.URL_DASHBOARD_TICKET_REASSIGN = this.URL_STUB_BASE+"/dashboard/setReassignTicket.json";
    }else{
    	this.URL_GET_DASHBOARD_RETRIEVE_REQUESTOR_FORM = this.URL_SERVER_BASE_WRAP + '/callBPMService?interfaceID=INT009';
    	this.URL_DASHBOARD_INBOX_GRID = this.URL_SERVER_BASE_WRAP + '/callBPMService?interfaceID=INT007';
    	this.URL_DASHBOARD_GROUP_UNITS = this.URL_SERVER_BASE_WRAP+"/callBPMService?interfaceID=INT017";
    	this.URL_DASHBOARD_TICKET_REASSIGN = this.URL_SERVER_BASE_WRAP +'/callBPMService?interfaceID=INT018';
    }
    
    //Email Template
    this.URL_GET_DASHBOARD_SUBMIT_EMAIL_TEMPLATE = this.URL_SERVER_BASE_WRAP + '/callBPMService?interfaceID=INT019';
    this.URL_GET_DASHBOARD_CREATE_EMAIL_TEMPLATE = this.URL_SERVER_BASE_WRAP + '/callBPMService?interfaceID=INT020';
    
    this.URL_GET_DASHBOARD_REVIEW_EMAIL_TEMPLATE = this.URL_SERVER_BASE_WRAP + '/callBPMService?interfaceID=INT022';
    this.URL_GET_DASHBOARD_REVIEW_CUSTOMER_SERVICE = this.URL_SERVER_BASE_WRAP + '/callBPMService?interfaceID=INT023';
    
    //NEWLY ADDED - EMAIL
    this.URL_DASHBOARD_EMAIL_TEMPLATE_DOC_DELETE = this.URL_SERVER_BASE_WRAP+"/deleteEmailTemplateDocs";    
    this.URL_DASHBOARD_EMAIL_TEMPLATE_DOC_DELETE_SENDEMAIL = this.URL_SERVER_BASE_WRAP+"/deleteEmailTemplateDocsVW";
    this.URL_DASHBOARD_EMAIL_TEMPLATE_DOC_GET_ALL_DOCS = this.URL_SERVER_BASE_WRAP+"/getEmailTemplateDocs";
    this.URL_DASHBOARD_EMAIL_TEMPLATE_DOC_INSERT = this.URL_SERVER_BASE_WRAP+"/insertEmailTemplateDoc";
    
    //Single View
    this.URL_GET_DASHBOARD_RETRIEVE_SINGLE_VIEW_FORM = this.URL_STUB_BASE+'/local/singleView.json';
    this.loadSingleView = true;
    
    //this.URL_DASHBOARD_GET_ALL_EMAIL_TEMPLATES = this.URL_STUB_BASE+"/local/templates.json";
    this.URL_DASHBOARD_GET_ALL_EMAIL_TEMPLATES = this.URL_SERVER_BASE_WRAP + '/callBPMService?interfaceID=INT021';
    
    //Managers Inbox
    this.URL_DASHBOARD_MANAGERS_INBOX_GRID = this.URL_SERVER_BASE_WRAP + '/callBPMService?interfaceID=INT016';
    
    this.URL_GET_META_DATA = this.URL_SERVER_BASE + '/callBPMService?interfaceID=INT002';
    //this.URL_GET_META_DATA = this.URL_STUB_BASE+'/local/localMetadata.json';
    this.URL_GET_META_DATA_LANG = this.URL_SERVER_BASE + '/callBPMService?interfaceID=INT027';
    
    //Navigation, tiles and left menu
    this.URL_DASHBOARD_NAVIGATION = this.URL_SERVER_BASE + '/callBPMService?interfaceID=INT004';    
    //this.URL_DASHBOARD_NAVIGATION = this.URL_STUB_BASE+'/dashboard/navigation.json';
    
    this.URL_DASHBOARD_HOME_PAGE_SUB_TILES = this.URL_SERVER_BASE + '/callBPMService?interfaceID=INT004';
    //this.URL_DASHBOARD_HOME_PAGE_SUB_TILES = this.URL_STUB_BASE+"/dashboard/leftMenuBar.json";
    
    this.URL_CREATE_REQUESTOR_INFORMATION = this.URL_SERVER_BASE + '/callBPMService?interfaceID=INT005';
    this.URL_CREATE_BUSINESS_CONTACT_DETAILS = this.URL_SERVER_BASE + '/callBPMService?interfaceID=INT006';
    
    //getting email template
    this.URL_GET_EMAIL_TEMPLATE = this.URL_SERVER_BASE + '/callBPMService?interfaceID=INT015';
    
    this.USERLIST = this.URL_STUB_BASE + '/dashboard/userlist.json';
    
    this.URL_CREATE_COMMODITY = this.URL_STUB_BASE + '/local/p2pcommodity.json';
    
    //CREATE
    this.URL_CREATE_AUDIT_TRAIL_CASP_CHECKER = this.URL_STUB_BASE + '/local/smduCaspCheckerAuditTrail.json';
    
    /*
    this.URL_CREATE_METHOD = this.URL_STUB_BASE + '/local/method.json';
    this.URL_CREATE_REGION = this.URL_STUB_BASE + '/local/region.json';
    this.URL_CREATE_ACTIONTYPE = this.URL_STUB_BASE + '/local/actiontype.json';
    this.URL_CREATE_COUNTRY = this.URL_STUB_BASE + '/local/country.json';
    this.URL_CREATE_REQUESTER_AUDIT_TRAIL = this.URL_STUB_BASE + '/local/requesterTPUAuditTrail.json';
    this.URL_CREATE_REQUESTER_TPU_ATTACHMENT = this.URL_STUB_BASE + '/local/requesterTPUAttachment.json';
    this.URL_CREATE_BUSINESS_CONTACT_LIST = this.URL_STUB_BASE + '/local/busineeContactList.json';
    */
    
    //this.URL_DASHBOARD_GET_ALL_FILES_GETALLDOCS = this.URL_SERVER_BASE_WRAP+"/getAllDocuments";
    this.URL_DASHBOARD_GET_ALL_FILES_GETALLDOCS = this.URL_MATCHDETAILS_POP_MATCH_DETAILS_GET_UPLOADEDFILES_NEW;
    this.URL_DASHBOARD_GET_ALL_FILES_UPLOADED = this.URL_SERVER_BASE_WRAP+"/upload";
    this.URL_UPLOAD_DELETE_DOC = this.URL_SERVER_BASE+"/delete";
    this.URL_UPLOAD_DELETE_DOC = this.URL_SERVER_BASE_WRAP +'/deleteFile';//rowId , requestId
    this.URL_UPLOAD_DOWNLOAD_DOC = this.URL_SERVER_BASE_COMMON +'/download';
    
    if(this.isLocalMethod === "GET"){
    	this.URL_FILE_UPLOAD_PROXY = this.URL_STUB_BASE + '/dashboard/success.json';
    }else{
    	this.URL_FILE_UPLOAD_PROXY = this.URL_SERVER_BASE_WRAP +'/fileUploadErrorHandler';
    }
    //this.URL_DASHBOARD_GET_ALL_FILES_UPLOADED = "http://localhost:8080/cwmweb/iQuery/data-stub/getAlldocs.json";
    
    this.URL_UPLOAD_ATTAHED_DOC = this.URL_DASHBOARD_GET_ALL_FILES_UPLOADED;
    //this.URL_UPLOAD_ATTAHED_DOC = this.URL_SERVER_BASE_WRAP +'/upload';   
    
    //this.URL_UPLOAD_ATTAHED_DOC = 'http://localhost:8080/cwmweb/iQuery/data-stub/uploadfile.json';
    
    //this.URL_METADATA_DYN_COMMENTS_HISTORY_GRID = 'http://localhost:8080/cwmweb/iQuery/data-stub/history/commentsHistory.json?interfaceID=INT007';
	this.URL_METADATA_DYN_COMMENTS_HISTORY_GRID = this.URL_SERVER_BASE + '/callBPMService?interfaceID=INT008'; 
    
	//TPU Analysis
	this.URL_CASP_CHECKER_AUDIT_TRAIL = this.URL_STUB_BASE + '/local/smduCaspCheckerAuditTrail.json';
	this.URL_CASP_CHECKER_ATTACHMENT = this.URL_STUB_BASE + '/local/attachment.json';
	
	
	//TODO:- Need to change later
	/*if(this.isMethodForThis == "GET" && this.matchDetailsNewService == true){		
	    this.URL_MATCHDETAILS_POP_MATCH_GETLIST = this.URL_STUB_BASE + '/matchDetails/getMatchInBulk.json';
	}
	if(this.isMethodForThis == "GET" && this.docUploadNewService == true){		
		this.URL_DASHBOARD_GET_ALL_FILES_GETALLDOCS = this.URL_STUB_BASE + '/dashboard/getAllDocs.json';
	}*/
	
	if(this.isMethodForThis == "POST" && this.matchDetailsNewService == true){		
		this.URL_MATCHDETAILS_POP_MATCH_BULK_GETLIST = this.URL_SERVER_BASE_WRAP + '/getMatchInBulk';
		//this.URL_MATCHDETAILS_POP_MATCH_BULK_GETLIST = this.URL_MATCHDETAILS_POP_MATCH_GETLIST;
	}
	if(this.isMethodForThis == "POST" && this.docUploadNewService == true){
		this.URL_DASHBOARD_GET_ALL_FILES_GETALLDOCS_INBULK = this.URL_SERVER_BASE_WRAP+"/getAllDocumentsInBulk";
	}
		
	this.URL_DYNAMIC_COMPONENT_FORM = this.URL_STUB_BASE+'/dynamicForm/dynform.json';
	
	this.URL_CUSTOMER_SERVICE_REPORT = this.URL_SERVER_BASE_WRAP+"/getCustomerServiceReportCSV";
	
	this.showSlownessLogs = false;
	 
	//Run with dummy json ; true - locally, false - live
	this.RUN_APP_FOR_SLOWNESS_TEST = false; 
	
	this.RUN_APP_FOR_SLOWNESS_TEST_METHOD = "GET";
	
	//Run Inbox at the beginning of app load ; TRUE - yes we can load, FALSE - lets wait till inbox grid is rendered
	this.RUN_INBOX_BEFORE_LOAD = true; 
	
	//Show request/response logs on each call, true - show log, false - hide log
	this.EVERY_AJAX_REQ_RES_LOG = false;
	
	//Make it 50 after testing - Paging
	this.EVERY_GRID_PAGE_SIZE = 20;
	if(this.RUN_APP_FOR_SLOWNESS_TEST == true){
		//INT002
		this.URL_GET_META_DATA = this.URL_STUB_BASE + '/systemSlow/INT002.json';
		
		//INT004
		this.URL_DASHBOARD_NAVIGATION = this.URL_STUB_BASE + '/systemSlow/INT004_nav.json';
	    this.URL_DASHBOARD_HOME_PAGE_SUB_TILES = this.URL_STUB_BASE + '/systemSlow/INT004_tiles.json';
	    
	    //INT007
	    this.URL_DASHBOARD_INBOX_GRID = this.URL_STUB_BASE + '/systemSlow/INT007.json';
	}
	
	// Request Templates
	this.URL_GET_REQUEST_TEMPLATE_SERVICE = this.URL_SERVER_BASE_WRAP + '/callBPMService?interfaceID=INT029';
	this.URL_ADD_TEMPLATE_SERVICE = this.URL_SERVER_BASE_WRAP + '/callBPMService?interfaceID=INT028';
	
	
	this.URL_ADD_HOLIDAY_CALENDAR = this.URL_SERVER_BASE_WRAP + '/callBPMService?interfaceID=INT030';
	this.URL_ALL_HOLIDAY_DATA = this.URL_SERVER_BASE_WRAP + '/callBPMService?interfaceID=INT031';
	 
    this.URL_VERIFY_ONLINE_REPORT = this.URL_SERVER_BASE_WRAP +'/verifyIsOffLineReport';
    this.URL_DATA_DUMP_HISTORY_REPORT = this.URL_SERVER_BASE_WRAP +'/dataDumpReportHistory';
    
    this.ACTION_TYPE_REQUIREMENT_DOC_URL = 'https://commercial.collaborationtools.consumer.citigroup.net/sites/tpu/TPU External/TPU SMDU/Supporting Documents/SMDU_Supporting_Document_Matrix.xlsm'
    
    this.offlineDashboardReport = false;
	 if(this.offlineDashboardReport == true){
		this.URL_DASHBOARD_REPORT_GRID_DATA = this.URL_STUB_BASE + '/reports/gridData.json';
	    this.URL_DASHBOARD_REPORT_CHART_DATA = this.URL_STUB_BASE + '/reports/barChart.json';
	}else{
		this.URL_DASHBOARD_REPORT_GRID_DATA = this.URL_SERVER_BASE_WRAP + '/getDashboardGridData';
	    this.URL_DASHBOARD_REPORT_CHART_DATA = this.URL_SERVER_BASE_WRAP + '/getDashboardChartData';	
	}
	
	this.URL_DOWNLOAD_CHART = this.URL_SERVER_BASE + '/downloadChart';
    this.URL_DETAIL_GRID_DOWNLOAD_CSV = this.URL_SERVER_BASE + '/getVolumeGridReportCSV';
    
    this.URL_PREFERED_LANG_FROM_BACKEND = this.URL_SERVER_BASE + '/getUserPreferenceLang';
	
    this.offlineSavedReports = false;
	 if(this.offlineSavedReports == true){
		 this.URL_SAVED_REPORT_GRID_DATA = this.URL_SERVER_BASE + '/getsavedFilterGridData';
		this.URL_GET_STANDARD_REPORTS_SERVICE = this.URL_SERVER_BASE + '/getStandardGridData';
		this.URL_GET_CYCLETIME_REPORTS_SERVICE = this.URL_SERVER_BASE + '/getCylceTimeGridReport';
		this.URL_DELETE_SAVED_REPORTS_SERVICE = this.URL_SERVER_BASE + '/deleteSavedFilterLog';
		this.URL_GET_CYCLETIME_REPORT_DETAIL_SERVICE = this.URL_SERVER_BASE + '/getCylceTimeGridDetailReport';
		this.SAVED_METHOD_REPORT = 'GET';
	}else{
		this.URL_SAVED_REPORT_GRID_DATA = this.URL_SERVER_BASE + '/getsavedFilterGridData';
		this.URL_GET_CYCLETIME_REPORTS_SERVICE = this.URL_SERVER_BASE + '/getCylceTimeGridReport';
		this.URL_GET_STANDARD_REPORTS_SERVICE = this.URL_SERVER_BASE + '/getStandardGridData';
		this.URL_DELETE_SAVED_REPORTS_SERVICE = this.URL_SERVER_BASE + '/deleteSavedFilterLog';
		this.URL_GET_CYCLETIME_REPORT_DETAIL_SERVICE = this.URL_SERVER_BASE + '/getCylceTimeGridDetailReport';
		this.SAVED_METHOD_REPORT = 'GET';
	}
	 
    return this;
    
 };

var Constants = AppConstants();
