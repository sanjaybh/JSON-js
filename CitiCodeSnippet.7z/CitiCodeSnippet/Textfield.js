Ext.define('SMDU.view.overrides.Textfield', {
    override :'Ext.form.field.Text',
    alias: 'widget.overtextfield',
    
    upper: true,
    defaultValue: '',
    enableKeyEvents: true,
    fieldStyle: {
    	display: 'inherit'
    },
    commonObj: Ext.create('widget.bi_common_functions'),
    
    launchComponent: function(config){
    	var me = this;
    	if(Ext.isEmpty(this.getValue()) == true && this.xtype == "textarea"){
    		Ext.apply(this, { value: this.defaultValue });
    	}
    	me.callParent(arguments);
    },
    
	onKeyUp: function(e) { 
		var val = this.getValue();
        if (this.upper && val) {
        	  var newVal = val.toString().toUpperCase();
        	  //val = Ext.util.Format.trim(newVal);      	  
        	  val = this.commonObj.lTrim(newVal);
        	  var el = this.inputEl.dom;
	          var selectionEnd = el.selectionEnd;
	          this.setValue(val.toString().toUpperCase());
	          this.setCaretTo(el, selectionEnd);
        }
        this.fireEvent('keyup', this, e); 
	},
	
	setCaretTo : function(obj, pos) {
        if(obj.createTextRange) { 
        	var range = obj.createTextRange(); 
            range.move("character", pos); 
            range.select(); 
        } else if(obj.selectionStart) { 
            obj.focus(); 
            obj.setSelectionRange(pos, pos); 
        } 
	}	
});