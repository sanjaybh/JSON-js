Ext.define("SMDU.view.common.DTiles", {
    extend: "Ext.view.View",
    alias: "widget.swiftux_view_tiles",
    autoScroll: true,
    defaultSwiftConfig: {
        tileWidth: 120,
        tileHeight: 120,
        tileMargin: 4,
        storeAutoLoad: false,
        clsLargeTextTile: "",
        clsSmallTextTile: ""
    },

    initComponent: function () {
        Ext.isEmpty(this.swiftConfig) ? this.swiftConfig = this.defaultSwiftConfig : Ext.applyIf(this.swiftConfig, this.defaultSwiftConfig);
        this.tpl = new Ext.XTemplate("<div>", '<ul class="swiftux-tiles">', '<tpl for=".">', '<li class="swiftux-tile" style="background-color:{BGCOLOR}; margin:{[this.getTileMargin()]}px; cursor:{[this.getCursor(values.CARD)]};">', '<div style="{[this.getDimensions(values.IS_DOUBLE)]}">', '<div style="height:85%;">', "<tpl if=\"TYPE == 'image'\">", '<div style="text-align:center;padding-top:15px;"><img src="{CONTENT}"></div>', "</tpl>", "<tpl if=\"TYPE == 'textLg'\">", '<div class="{[this.getTileLgTextCls()]}" style="text-align:center;">{CONTENT}</div>', "</tpl>", "<tpl if=\"TYPE == 'textSm'\">", '<div class="{[this.getTileSmTextCls()]}">{CONTENT}</div>', "</tpl>", "</div>", '<div class="swiftux-tile-caption">{LABEL}</div>', "</div>", "</li>", "</tpl>", "</ul>", "</div>", {
            getDimensions: Ext.Function.bind(function (a) {
                if (a === true) {
                    return "width:" + ((this.swiftConfig.tileWidth * 2) + (this.swiftConfig.tileMargin * 2)) + "px;height:" + this.swiftConfig.tileHeight + "px;"
                }
                return "width:" + (this.swiftConfig.tileWidth - 11) + "px;height:" + this.swiftConfig.tileHeight + "px;"
            }, this),
            getTileMargin: Ext.Function.bind(function () {
                return this.swiftConfig.tileMargin
            }, this),
            getCursor: Ext.Function.bind(function (a) {
                return Ext.isEmpty(a) ? "default" : "pointer"
            }, this),
            getTileLgTextCls: Ext.Function.bind(function () {
                return this.swiftConfig.clsLargeTextTile
            }, this),
            getTileSmTextCls: Ext.Function.bind(function () {
                return this.swiftConfig.clsSmallTextTile
            }, this)
        });
        this.itemSelector = "li.swiftux-tile";
        this.loadMask = false;
        this.store = Ext.create("Ext.data.Store", {
            fields: ["LABEL", "BGCOLOR", "IS_DOUBLE", "TYPE", "CONTENT", "CARD", "REF", "tilereference", "hidden", "target"],
            autoLoad: this.swiftConfig.storeAutoLoad,
            proxy: {
                type: "ajax",
                url: this.swiftConfig.storeUrl,
                extraParams: this.swiftConfig.extraParams,
                actionMethods: {
                    create: 'POST',
                    read: 'POST',
                    destroy: 'POST',
                    update: 'POST'
                },
                reader: {
                    type: "json",
                    rootProperty: "data",
                    successProperty: "success"
                }
            },
            listeners: {
                "load": {
                    fn: function () {
                        //Ext.ComponentQuery.query('home_leftdataview')[0].down('dataview').setStore(this);
                    }
                }
            }
        });
        this.callParent(arguments)
    }
});
 