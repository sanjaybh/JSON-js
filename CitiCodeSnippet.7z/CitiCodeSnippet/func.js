function getTable(tableItem, loopTo){
	var _loopTo = loopTo || 10;
	if(tableItem == undefined){
		console.log('Empty function call'); 
		return true;
	} else if(isNaN(tableItem) == true){
		console.log('Not a number'); 
		return true;
	}
	tableItem = parseInt(tableItem);
    for(var i=1;i<=_loopTo;i++){
        var val = tableItem * i;
        console.log(tableItem + " * " + i + " = " + val);
    }
}