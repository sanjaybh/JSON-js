Ext.Loader.setConfig({
	enabled: true, 
	disableCaching: false 
});

/*
	Ext.Loader.setConfig({enabled:true, disableCaching: false});
	Ext.data.Connection.disableCaching = false;
	Ext.data.JsonP.disableCaching = false;
	Ext.data.proxy.Server.prototype.noCache = false;
	Ext.Ajax.disableCaching = false;
*/

/*
 * This file is generated and updated by Sencha Cmd. You can edit this file as
 * needed for your application, but these edits will have to be merged by
 * Sencha Cmd when upgrading.
 */

Ext.application({
    name: 'SMDU',

    extend: 'SMDU.Application',
    
    requires: [
    	'Ext.chart.*',
       'SMDU.view.overrides.HtmlEditor',
       'SMDU.view.overrides.Filters',
       'SMDU.view.overrides.String',
       'SMDU.view.overrides.ComboBox',
       'SMDU.view.overrides.Date',
       'SMDU.view.LayoutContainer',
       'SMDU.view.common.CommonFx',
       'SMDU.view.common.NavigationItem',       
       'SMDU.view.common.NavigationButton'
       ,'SMDU.widgets.SessionMonitor'
    ],
        
    stores: ['AuditTrails','InboxGrid'],
    
	postMetaLaunch: function() {  
		Ext.create("Ext.container.Viewport", {
			layout:{type:"fit"},
			items: {
				xtype:"view_homecontainer" //this is LayoutContainer.js(view_homecontainer)
			}
		});		
		var elem = document.getElementById('apploading');
		elem.parentNode.removeChild(elem);		
	},
	
	launchDumyPanel: function(){
		var elem = document.getElementById('apploading');
		
		return Ext.create("Ext.panel.Panel", {
			title:'main panel', html: 'Main Title of the page', renderTo: Ext.getBody()
		});
	},
	
	launch: function () { 
		var me = this;
			
		me["relogin"] = "Session expired, kindly login again.";
		me["loginTag"] = "<form action";
		
		SMDU.gbl = {
			"userDetail": {
				"PREF_LANG" : '',
				"HOME_CONT_REF": null
			},
			"requestorInfo":{
				"requestorSoeid": null,
				"isCityEmployee": null,
				"formType" : null,
				"onBehalfOf": {
					"isCityEmployee": null
				}
			}
		};
		//
		var prefLang = Ext.create('widget.bi_common_functions').getPrefLanguage(this);
		SMDU.gbl.userDetail.PREF_LANG = prefLang;
		SMDU.gbl["loggedInUser"] = {};
		me.getServerCurrTime();
		
		var appPath = window.location.href; 
		var isLocal = false;
		if(appPath.indexOf('localhost') > -1 ){
			isLocal = true;
		}
		console.log("Language = "+SMDU.gbl.userDetail.PREF_LANG);
				
		//SMDU.gbl.hideMenu = undefined;
		me.handlerAjaxError();
		
		if(Constants.RUN_INBOX_BEFORE_LOAD === true){
			me.getInboxDataInitially();
		}
		
		//modifying actionMethods because SSO is blocking XSS related "badCssChars"
		Ext.data.proxy.Ajax.prototype.actionMethods = {create:"POST",read:"POST",update:"POST",destroy:"POST"};
		
		//don't convert special characters to naming entities, Native browser parsing for JSON
		Ext.USE_NATIVE_JSON = true;
		
		//Ext.data.proxy.Ajax.prototype.extraParams = {'language':'english'};
						
		Ext.apply(Ext.form.VTypes, {
		    emails: function(value, field) {
		        var email = /^(")?(?:[^\."])(?:(?:[\.])?(?:[\w\-!#$%&'*+/=?^_`{|}~]))*\1@(\w[\-\w]*\.){1,5}([A-Za-z]){2,6}$/;
		        var emailIds = [];
		        if (value instanceof Array) {
		            emailIds = value;
		        } else if (value.indexOf(",") != -1) {
		            emailIds = value.split(",");
		        } else {
		            emailIds[0] = value;
		        }
		        for (var i = 0; i < emailIds.length; i++) {
		            if (!email.test(emailIds[i])) return false;
		        }
		        return true;
		    },
		    emailsText: 'Please enter valid email(s)',
		    emailsMask: /[\w.\-@'"!#$%&'*+/=?^_`{|}~,]/i
		});
		
		Ext.create('widget.bi_common_functions').loadLocale(me.afterLocaleSet, me);
		
	},
    
	afterLocaleSet: function(){
		var me = this;
		var parentPath = window.parent.location.href;
		var appPath = window.location.href;
		// Trying to set selected language labels to common_lang(lang_eng).

		if(parentPath === appPath && appPath.indexOf('localhost') > -1 ){
			me.getNavigation();//TODO:- Need to uncommit later
			me.getMetaDataForInit();
			SMDU.gbl["hideMenu"] = false;
		}else{
			me.getMetaDataForInit();
			SMDU.gbl["hideMenu"] = true;
		}
	},
	
	getInboxDataInitially: function(rec_, me){
    	//NOTE:- set Request for Manager if the flag is true
    	var _URL = Constants.URL_DASHBOARD_INBOX_GRID;
    	//_URL += "&requestJson=" + Ext.encode({"requestId": rec_.data.requestId});
    	
    	if(Constants.EVERY_AJAX_REQ_RES_LOG == true){
    		Ext.create('widget.bi_common_functions').showSlownessLogs('SendAjaxRes - Request Send', 'Start', _URL, 'YES');
    	}
    	
    	var inboxStore = Ext.getStore('InboxGrid');
    	
    	inboxStore.getProxy().extraParams = {
			"actionFrom":"inboxtabs", 
			'language': SMDU.gbl.userDetail.PREF_LANG,
			"requestJson": Ext.encode({"language" : SMDU.gbl.userDetail.PREF_LANG})
		}
    	inboxStore.proxy.url =  _URL;
    	inboxStore.load({
    		callback : function (items) { 			
    			//if(!Ext.isEmpty(inboxStore.data.items[0]) && !Ext.isEmpty(inboxStore.data.items[0].data))
    			//dataObject = Ext.decode(inboxStore.data.items[0].data.data.commentsHistoryOutData);
    			
    			if(Constants.EVERY_AJAX_REQ_RES_LOG == true){
	            	Ext.create('widget.bi_common_functions').showSlownessLogs('SendAjaxRes - Response Received', 'End', _URL, 'YES');
	        	}
    			
    			var meta, locVariable;
				if(Constants.RUN_APP_FOR_SLOWNESS_TEST === true){
					locVariable = Ext.decode(items[0].data.data.data.inboxData);
				}else{
					if(items[0] !== undefined){
						locVariable = items[0].data;
					}else{
						locVariable = []
					}					
				}
				
				//locVariable["total"] = locVariable.data.length;
				SMDU.gbl["_inboxGrid_"] = locVariable;
    			//inboxStore.loadData(items[0].data.data);
    		}
    	});
    },
    	
	isSessionActive: function(response_){
		var me = this;
		if(Constants.enableSessionTimeout === true){
			if(response_.responseText.indexOf(me.loginTag) > -1){
				Ext.Msg.alert('Alert!', me.relogin);
				Ext.create('widget.bi_common_functions').logoutFuntion();
				return false;
			}else{
				return true;
			}
		}else{
			return true;
		}
		
	},
	
	getMetaDataForInit: function(){
		var me = this;
		var _url = URL_GET_META_DATA; // metadata - English Language
		
		var _params = {
			'language': SMDU.gbl.userDetail.PREF_LANG
		};
		
		Ext.Ajax.request({
			url: _url, //Get Meta Data
			method: Ext.create('widget.bi_common_functions').sendMethod() || 'POST',
			timeout: Constants.ajaxReqTimeout,
			disableCaching: false,
			scope: this,
			params : {
	        	'requestJson' : Ext.encode(_params), 'language': SMDU.gbl.userDetail.PREF_LANG
	        },
			success: function(response_) {
				if((response_.responseText).indexOf('SiteMinder') > -1){
					Ext.Msg.alert('Alert!', response_.responseText);
					Ext.get('apploading').dom.innerHTML = response_.responseText;
					return false;
				}
				
				if(me.isSessionActive(response_) == true){
					var respText = Ext.decode(response_.responseText);
					if(respText.success === "false"){
						Ext.Msg.alert('Alert!', respText.message);
						return false;
					}else{ 
						SMDU.gbl.meta = Ext.decode(respText.data.data.metadata);
						if(SMDU.gbl.meta === null){
							Ext.Msg.alert('Alert!', "Main metadata service is failing, please connect with admin.");
							return false;
						}else{
							SMDU.gbl.meta.USER_ROLE = '_BLANK';
							SMDU.gbl.meta.userDetails = Ext.decode(response_.responseText).data.data.userDetails;
							SMDU.gbl.meta.defaultPage = Constants.URL_DEFAULT_PAGE;
							
							//Note:- Call Post Launch only after metaData service is loaded into the application objects
							me.postMetaLaunch();
						}						
					}
				};												
			},
			failure: function(response_) {
				console.error('Server request encountered an error. Please contact admin. ', response_);
			}
		});
	},
	
	islocalHost: function(){
		//TODO:- do you need top Citi banner and logo, in local; yes we need it
		var parentPath = window.parent.location.href;
		var appPath = window.location.href;	
		if(parentPath === appPath && appPath.indexOf('localhost') > -1 ){
			return false;
		}else{
			return true;
		}
	},
	
	changeTypeCastingFor: function(type){
		//if(this.islocalHost() == true){ return false; }
		
		//Note:- Change true to false and false to true (for hidden != what we sent)
		if(type == "true" || type == true){
			return false;
		}else{
			return true;
		}
	},
	
	getServerCurrTime: function(){		
		var me = this;			
		Ext.Ajax.request({
			url: Constants.URL_METADATA_GET_CURR_DATETIME, //Get Current Time
			method: 'POST',
			timeout: Constants.ajaxReqTimeout,
			//disableCaching: false,
			scope: this,
			async:true,
			params: {'language': SMDU.gbl.userDetail.PREF_LANG},
			success: function(response_) {
				if(response_.status == '200'){ 					
					if(me.isSessionActive(response_) == true){
						var json = Ext.decode(response_.responseText);
						
						SMDU.gbl["toDaysDate"] = json.dateTime; 
						SMDU.gbl["loggedInUser"] = {							
						    "isTemplateAdmin" : me.changeTypeCastingFor(json.isTemplateAdmin),
						    "currLoggedInSoeid" : (json.currLoggedInSoeid == undefined) ? "_BLANK" :  json.currLoggedInSoeid,
						    "userLoggedIn"	:  (json.userLoggedIn == undefined) ? "_BLANK" :  json.userLoggedIn,
						    "sessionTimeout" :  (json.sessionTimeout == undefined) ? "_BLANK" :  json.sessionTimeout
						};
						SMDU.gbl["OOO_LoggedInUser"] =  (json.userLoggedIn == undefined) ? "_BLANK" :  json.userLoggedIn;
						SMDU.gbl["loggedInUserManagerDetail"] = {
							managerSOEID : json.managerSOEID,
							managerEmail : json.managerEmail
						}
						if(Ext.isEmpty(json.userLoggedIn)){
							Ext.Msg.alert('Alert!', "Logged in user details are missing, kindly connect with Admin.");
							return false;
						}
						if(Constants.enableSessionTimeout === true){
							var _sessionTimeout = (SMDU.gbl.loggedInUser.sessionTimeout !== undefined) ? ((SMDU.gbl.loggedInUser.sessionTimeout) - 60 * 4) * 1000 : Constants.sessionTimeout;
							if(Constants.sessionTimeoutLog === true){
								_sessionTimeout = 2*60; //TODO:- only for testing
							}							
							var swiftConfig = {
								maxInactive: _sessionTimeout, //pass sec here
								interval: 1000 * 10 //sync with object every 10 sec
							}
							SMDU.widgets.SessionMonitor.initComponent(swiftConfig);
						}
					}
				}
			},
			failure: function(response_) {
				console.error('Server request encountered an error. Please contact admin. ', response_);
			}
		});
	},
		
	getNavigation: function(){
		var me = this;
		var passObj = {"type": "nav"};	
		
		Ext.Ajax.request({
			url: Constants.URL_DASHBOARD_NAVIGATION, //GET Navigation - INT004
			method: Ext.create('widget.bi_common_functions').sendMethod() || 'POST',
			timeout: Constants.ajaxReqTimeout,
			scope: this,
			disableCaching: false,//21stMarch
			params : {
	        	'requestJson' : Ext.encode(passObj), 'language': SMDU.gbl.userDetail.PREF_LANG
	        },
			success: function(response_) { 
				var ms = new Date();
				if((response_.responseText).indexOf('SiteMinder') > -1){
					Ext.Msg.alert('Alert!', response_.responseText);
					Ext.get('apploading').dom.innerHTML = response_.responseText;
					return false;
				}
				//userSoeid
	            if(response_.responseText.indexOf('userSoeid') > -1){ 
	            	Ext.Msg.alert('Alert!', 'Session expired..., kindly login again. - ' + ms);
					return false;
				}
				if(response_.status == '200'){
					if(me.isSessionActive(response_) == true){
						if(Ext.decode(response_.responseText).success == 'false'){
							var msg = Ext.decode(response_.responseText).message+", please contact admin.";
							Ext.Msg.alert('Alert!', msg);
							Ext.get('apploading').dom.innerHTML = msg;
							return false;
						}
					}					
				}
				
				SMDU.gbl.navigation = Ext.decode(response_.responseText).data[0].navigation;
				//SMDU.gbl["toDaysDate"] = Ext.decode(response_.responseText).data[0].todaysDate;
				
				SMDU.gbl["loggedInUser"] = {};
	        	//Make metadata call before any rendering happens or app launches
				
				//TODO:- do you need top Citi banner and logo, in local; yes we need it
				var parentPath = window.parent.location.href;
				var appPath = window.location.href;	
				
				if(parentPath === appPath && appPath.indexOf('localhost') > -1 ){
					SMDU.gbl["hideMenu"] = false;
				}else{
					SMDU.gbl["hideMenu"] = true;
				}				
			},
			failure: function(response_) {
				console.error('Server request encountered an error. Please contact admin. ', response_.statusText);
			}
		});
	},
	
    generateUniqueNumber: function() {
    	var me = this;
    	var _result;
    	var returnHandlerJSON = function(json){
    		if(json.success == "true"){
    			var dt = new Date(json.milliSeconds);   			
    		}else{
    			var dt = new Date();    			
    		}
    		SMDU.gbl.meta.timestamp = "REQ"+Ext.util.Format.date(dt, 'mdYisu');//Ymdhisu
    		_result = SMDU.gbl.meta.timestamp;
    		
    		return _result;
    	}
    	var _URL = Constants.URL_METADATA_GET_CURR_DATETIME;
    	Ext.create('widget.bi_common_functions').sendAjaxRequest(_URL, 'POST', returnHandlerJSON, {'ts':true}, this);
    },
    
    removeLoadmask: function(){ 
		//remove the loadmask if present
		Ext.each(Ext.ComponentQuery.query('loadmask'), function(mask) {
			if(mask.rendered && !mask.isHidden()) {
				mask.hide();
			}
		});
	},
	
    verifyActiveSession: function(){
    	var updateClock = function () {
		    console.log(Ext.Date.format(new Date(), 'g:i:s A'));
    		Ext.Ajax.request({
				url: Constants.URL_KEEP_SESSION_ALIVE,
				method: 'POST',
				timeout: Constants.ajaxReqTimeout,
				params:{'language': SMDU.gbl.userDetail.PREF_LANG},
				success: function(result) {
    				var json = Ext.decode(result.responseText);
					if(json.success !== true){
						Ext.Msg.alert('Alert!', json.data.message)
						var _commonFn = Ext.create('widget.bi_common_functions');
						_commonFn.logoutFuntion();
					}
				},
				failure: function() {
					console.log('URL_KEEP_SESSION_ALIVE fail!')
				}
			});
		 };
    },
        
    handlerAjaxError: function(){
		var me = this;
		Ext.Ajax.on('requestexception', function(conn, response, options) {
			var scopeObj = options.scope || {},
				isAjaxProxy = scopeObj.isAjaxProxy,
				hasExceptionHandler = options && Ext.isFunction(options.failure),
				result = {};
			try{
				result = Ext.decode(response.responseText);
			}catch(err) {
			   return;
			}
			if(isAjaxProxy && scopeObj.initialConfig.listeners && scopeObj.initialConfig.listeners.exception) {
				hasExceptionHandler = true;
			}
			if(response.aborted !== true) {
				console.error(response, options);
				me.removeLoadmask();
				//show error message for the unhandled exception
				if(!hasExceptionHandler) {
					Ext.Msg.alert('Error', (result && result.errorMsg) || response.statusText);
				}
			}
		});
	},

	getParentApp: function() {
		var parentAppObj = window.parent.Portal;
		if(Ext.isEmpty(parentAppObj)) {
			// For IE
			parentAppObj = window.top.document.Portal;
		}
	   
		return parentAppObj;
    }
    //-------------------------------------------------------------------------
    // Most customizations should be made to SMDU.Application. If you need to
    // customize this file, doing so below this section reduces the likelihood
    // of merge conflicts when upgrading to new versions of Sencha Cmd.
    //-------------------------------------------------------------------------
});
